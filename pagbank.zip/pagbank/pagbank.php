<?php
/*
 * PagBank
 * 
 * Módulo Oficial para Integração com o PagBank via API v.4
 * Checkout Transparente para PrestaShop 1.6.x ao 9.x
 * Pagamento com Cartão de Crédito, Google Pay, Pix, Boleto e Pagar com PagBank
 * 
 * @author
 * 2011-2026 PrestaBR - https://prestabr.com.br
 * 
 * @copyright
 * 1996-2026 PagBank - https://pagbank.com.br
 * 
 * @license
 * Open Software License 3.0 (OSL 3.0) - https://opensource.org/license/osl-3-0-php/
 *
 */

if (!defined('_PS_VERSION_')) {
	exit;
}
if (_PS_VERSION_ >= '1.7.0') {
	include_once _PS_MODULE_DIR_ . 'pagbank/controllers/v8/PagBankV8Class.php';
} else {
	include_once _PS_MODULE_DIR_ . 'pagbank/controllers/v6/PagBankV6Class.php';
}

class PagBank extends PaymentModule
{
	public $environment;
	public $google_environment;
	public $ps_params;
	public $urls;
	public $number_field;
	public $compl_field;
	public $ps_errors;
	public $authorization_code;
	public $credential_type;
	public $pag_controller;
	public $token;
	public $api_info;
	public $client_id;
	public $cryptogram;
	public $public_key;
	public $ready;
	public $device;
	public $shop_id;
	public $account_id;

	/*
	 * Função inicial da classe
	 * Define os parâmetros básicos e eventuais validações do módulo
	 */
	public function __construct()
	{
		$this->name = 'pagbank';
		$this->tab = 'payments_gateways';
		$this->version = '2.2.0';
		$this->author = 'PrestaBR';
		$this->displayName = $this->l('PagBank - Checkout Transparente');
		$this->description = $this->l('Módulo Oficial API v.4 - PrestaShop 1.6.x ao 9.x');
		$this->limited_countries = array('BR');
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
		$this->bootstrap = true;
		$this->urls = array(
			'notification' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'module/' . $this->name . '/notify?token='.$this->getTokenHash(),
			'update' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'module/' . $this->name . '/update',
			'img' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $this->name . '/img/'
		);
		$this->credential_type = Configuration::get('PAGBANK_CREDENTIAL');
		$this->environment = Configuration::get('PAGBANK_ENVIRONMENT');
		$this->google_environment = Configuration::get('PAGBANK_GOOGLE_ENVIRONMENT');
		if ((int)$this->environment == 1) {
			$this->urls['api'] = 'https://api.pagseguro.com/';
			$this->urls['installments'] = 'https://api.pagseguro.com/charges/fees/calculate';
			$this->urls['connect'] = 'https://connect.pagseguro.uol.com.br/oauth2/authorize';
			$this->urls['refresh'] = 'https://api.pagseguro.com/oauth2/refresh';
			$this->urls['appauth'] = 'https://api.pagseguro.com/oauth2/token';

			if ($this->credential_type === 'TAX' || !$this->credential_type || $this->credential_type === '') {
				$this->token = Configuration::get('PAGBANK_TOKEN_TAX');
			} elseif ($this->credential_type === 'D14') {
				$this->token = Configuration::get('PAGBANK_TOKEN_D14');
			} elseif ($this->credential_type === 'D30') {
				$this->token = Configuration::get('PAGBANK_TOKEN_D30');
			} else {
				$this->token = '';
			}
			$this->public_key = Configuration::get('PAGBANK_PUBLIC_KEY');
			$this->account_id = Configuration::get('PAGBANK_ACCOUNT_ID');
		} else {
			$this->urls['api'] = 'https://sandbox.api.pagseguro.com/';
			$this->urls['installments'] = 'https://sandbox.api.pagseguro.com/charges/fees/calculate';
			$this->urls['connect'] = 'https://connect.sandbox.pagseguro.uol.com.br/oauth2/authorize';
			$this->urls['refresh'] = 'https://sandbox.api.pagseguro.com/oauth2/refresh';
			$this->urls['appauth'] = 'https://sandbox.api.pagseguro.com/oauth2/token';

			if ($this->credential_type === 'TAX' || !$this->credential_type || $this->credential_type === '') {
				$this->token = Configuration::get('PAGBANK_TOKEN_SANDBOX_TAX');
			} elseif ($this->credential_type === 'D14') {
				$this->token = Configuration::get('PAGBANK_TOKEN_SANDBOX_D14');
			} elseif ($this->credential_type === 'D30') {
				$this->token = Configuration::get('PAGBANK_TOKEN_SANDBOX_D30');
			} else {
				$this->token = '';
			}
			$this->public_key = Configuration::get('PAGBANK_PUBLIC_KEY_SANDBOX');
			$this->account_id = Configuration::get('PAGBANK_ACCOUNT_ID_SANDBOX');
		}
		if ($this->active) {
			$this->api_info = $this->getApiInfo((int)$this->environment, $this->credential_type);

			$this->client_id = $this->api_info['client_id'];
			$this->cryptogram = $this->api_info['cipher_text'];
		}

		$this->context = Context::getContext();
		$shop_id = 1;
		if (!is_null($this->context->shop->id)) {
			$shop_id = (int)$this->context->shop->id;
			$this->shop_id = $shop_id;
		}

		if ($this->token != '' && (!$this->public_key || $this->public_key === '')) {
			$this->getPublicKey();
		}

		if (!$this->token || $this->token === '' || !$this->public_key || $this->public_key === '' || !$this->credential_type) {
			$this->ready = false;
		} else {
			$this->ready = true;
		}

		if (_PS_VERSION_ >= '1.7.0') {
			$this->pag_controller = new PagBankV8();
		} else {
			$this->pag_controller = new PagBankV6();
		}

		if ($this->context->isTablet()) {
			$this->device = "t";
		} elseif ($this->context->isMobile()) {
			$this->device = "m";
		} else {
			$this->device = "d";
		}

		$this->number_field = 'company';
		if (Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME = "' . _DB_PREFIX_ . 'address" AND COLUMN_NAME = "number"')) {
			$this->number_field = 'number';
		} elseif (Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME = "' . _DB_PREFIX_ . 'address" AND COLUMN_NAME = "numend"')) {
			$this->number_field = 'numend';
		}
		$this->compl_field = ($this->number_field === 'numend' ? 'compl' : 'other');

		parent::__construct();
	}

	/*
	 * Cria abas no menu e tabelas no banco
	 * Registra os Hooks da aplicação e define parâmetros de configuração
	 */
	public function install()
	{
		$iso_code = Country::getIsoById(Configuration::get('PS_COUNTRY_DEFAULT'));
		if (in_array($iso_code, $this->limited_countries) == false) {
			$this->_errors[] = $this->l('This module is not available in your country.');
		}

		include(dirname(__FILE__) . '/sql/install.php');

		if (!parent::install() || !$this->pag_controller->installation()) {
			return false;
		}else{
			//Credenciais
			Configuration::updateValue('PAGBANK_ENVIRONMENT', 1, false);
			Configuration::updateValue('PAGBANK_CREDENTIAL', '', false);
			Configuration::updateValue('PAGBANK_TOKEN_TAX', '', false);
			Configuration::updateValue('PAGBANK_TOKEN_D14', '', false);
			Configuration::updateValue('PAGBANK_TOKEN_D30', '', false);
			Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_TAX', '', false);
			Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_D14', '', false);
			Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_D30', '', false);
			Configuration::updateValue('PAGBANK_PUBLIC_KEY', '', false);
			Configuration::updateValue('PAGBANK_PUBLIC_KEY_SANDBOX', '', false);
			Configuration::updateValue('PAGBANK_ACCOUNT_ID', '', false);
			Configuration::updateValue('PAGBANK_ACCOUNT_ID_SANDBOX', '', false);
			Configuration::updateValue('PAGBANK_GOOGLE_MERCHANT_ID', '', false);
			Configuration::updateValue('PAGBANK_GOOGLE_ENVIRONMENT', 0, false);
			Configuration::updateValue('PAGBANK_GOOGLE_ORDER_DEMO', 1, false);
			Configuration::updateValue('PAGBANK_RECAPTCHA_SITE_KEY', '', false);
			Configuration::updateValue('PAGBANK_RECAPTCHA_API_KEY', '', false);

			//Opções de Pagamento
			Configuration::updateValue('PAGBANK_CREDIT_CARD', 1, false);
			Configuration::updateValue('PAGBANK_MAX_INSTALLMENTS', 12, false);
			Configuration::updateValue('PAGBANK_NO_INTEREST', 12, false);
			Configuration::updateValue('PAGBANK_MINIMUM_INSTALLMENTS', '1.00', false);
			Configuration::updateValue('PAGBANK_INSTALLMENTS_TYPE', 1, false);
			Configuration::updateValue('PAGBANK_SAVE_CREDIT_CARD', 1, false);
			Configuration::updateValue('PAGBANK_TWO_CREDIT_CARD', 0, false);
			Configuration::updateValue('PAGBANK_TWO_CREDIT_CARD_INST', 0, false);
			Configuration::updateValue('PAGBANK_CAPTURE_METHOD', 1, false);
			Configuration::updateValue('PAGBANK_BANKSLIP', 1, false);
			Configuration::updateValue('PAGBANK_BANKSLIP_DATE_LIMIT', 2, false);
			Configuration::updateValue('PAGBANK_BANKSLIP_TEXT', 'Pedido realizado na loja ' . Configuration::get("PS_SHOP_NAME"), false);
			Configuration::updateValue('PAGBANK_PIX', 1, false);
			Configuration::updateValue('PAGBANK_PIX_TIME_LIMIT', 30, false);
			Configuration::updateValue('PAGBANK_WALLET', 1, false);
			Configuration::updateValue('PAGBANK_WALLET_TIME_LIMIT', 1440, false);
			Configuration::updateValue('PAGBANK_GOOGLE_PAY', 0, false);
			Configuration::updateValue('PAGBANK_RECAPTCHA', 0, false);
			Configuration::updateValue('PAGBANK_RACAPTCHA_CRITERIA', 'MEDIUM', false);
			Configuration::updateValue('PAGBANK_RECAPTCHA_URL', '', false);

			//Status dos pedido
			Configuration::updateValue('PAGBANK_PAID', _PS_OS_PAYMENT_, false);
			Configuration::updateValue('PAGBANK_AUTHORIZED', Configuration::get('_PS_OS_PAGBANK_3'), false);
			Configuration::updateValue('PAGBANK_CANCELED', _PS_OS_CANCELED_, false);
			Configuration::updateValue('PAGBANK_REFUNDED', _PS_OS_REFUND_, false);
			Configuration::updateValue('PAGBANK_IN_ANALYSIS', Configuration::get('_PS_OS_PAGBANK_1'), false);
			Configuration::updateValue('PAGBANK_AWAITING_PAYMENT', Configuration::get('_PS_OS_PAGBANK_2'), false);

			//Configuração de Descontos
			Configuration::updateValue('PAGBANK_DISCOUNT_TYPE', 0, false);
			Configuration::updateValue('PAGBANK_DISCOUNT_VALUE', '0.00', false);
			Configuration::updateValue('PAGBANK_DISCOUNT_CREDIT', 0, false);
			Configuration::updateValue('PAGBANK_DISCOUNT_BANKSLIP', 0, false);
			Configuration::updateValue('PAGBANK_DISCOUNT_PIX', 0, false);
			Configuration::updateValue('PAGBANK_DISCOUNT_WALLET', 0, false);
			Configuration::updateValue('PAGBANK_DISCOUNT_GOOGLE', 0, false);

			//Gerenciamento de Banco de Dados, Log e Erros
			Configuration::updateValue('PAGBANK_CRON_WARNING', 0, false);
			Configuration::updateValue('PAGBANK_SHOW_CONSOLE', 0, false);
			Configuration::updateValue('PAGBANK_FULL_LOG', 1, false);
			Configuration::updateValue('PAGBANK_DELETE_DB', 0, false);
		}
		return true;
	}

	/*
	 * Remove abas no menu e tabelas no banco (caso tenha escolhido a opção na configuração do módulo)
	 * Remove os Hooks da aplicação e parâmetros de configuração
	 */
	public function uninstall()
	{
		if (!parent::uninstall() || !$this->pag_controller->uninstallTabs() || !$this->deleteStatus()) {
			return false;
		}

		if (!Db::getInstance()->delete("configuration", "name LIKE '%PAGBANK%'")) {
			return false;
		}

		if ((bool)Configuration::get('PAGBANK_DELETE_DB') === true) {
			include(dirname(__FILE__) . '/sql/uninstall.php');
		}
		return true;
	}

	/*
	 * Conteúdo da página de configuração do módulo
	 */
	public function getContent()
	{
		$output = '';

		if ((bool)Tools::isSubmit('submitPagBankModule') === true) {
			$update = $this->postProcess();
			if ($update !== false) {
				$output .= $this->displayConfirmation($this->l('Configurações atualizadas!'));
			}
		}
		$app_msg = Tools::getValue('app_msg');
		if (isset($app_msg) && $app_msg != '') {
			$output .= $this->displayConfirmation($app_msg);
		}

		if ((int)Configuration::get('PAGBANK_ENVIRONMENT') == 1) {
			$tax = Configuration::get('PAGBANK_TOKEN_TAX');
			$d14 = Configuration::get('PAGBANK_TOKEN_D14');
			$d30 = Configuration::get('PAGBANK_TOKEN_D30');
			$signin_connect_url = 'https://connect.pagseguro.uol.com.br/oauth2/authorize';
			$app_info_tax = $this->getApiInfo(1, 'TAX');
			$app_info_d14 = $this->getApiInfo(1, 'D14');
			$app_info_d30 = $this->getApiInfo(1, 'D30');
			$client_id_tax = $app_info_tax['client_id'];
			$client_id_d14 = $app_info_d14['client_id'];
			$client_id_d30 = $app_info_d30['client_id'];
		} else {
			$tax = Configuration::get('PAGBANK_TOKEN_SANDBOX_TAX');
			$d14 = Configuration::get('PAGBANK_TOKEN_SANDBOX_D14');
			$d30 = Configuration::get('PAGBANK_TOKEN_SANDBOX_D30');
			$signin_connect_url = 'https://connect.sandbox.pagseguro.uol.com.br/oauth2/authorize';
			$app_info_tax = $this->getApiInfo(0, 'TAX');
			$app_info_d14 = $this->getApiInfo(0, 'D14');
			$app_info_d30 = $this->getApiInfo(0, 'D30');
			$client_id_tax = $app_info_tax['client_id'];
			$client_id_d14 = $app_info_d14['client_id'];
			$client_id_d30 = $app_info_d30['client_id'];
		}

		Configuration::updateValue('PAGBANK_CODE_VERIFIER_TAX', $this->getPkceData('TAX', 'code_verifier'), false);
		Configuration::updateValue('PAGBANK_CODE_CHALLENGE_TAX', $this->getPkceData('TAX', 'code_challenge'), false);
		Configuration::updateValue('PAGBANK_CODE_VERIFIER_D14', $this->getPkceData('D14', 'code_verifier'), false);
		Configuration::updateValue('PAGBANK_CODE_CHALLENGE_D14', $this->getPkceData('D14', 'code_challenge'), false);
		Configuration::updateValue('PAGBANK_CODE_VERIFIER_D30', $this->getPkceData('D30', 'code_verifier'), false);
		Configuration::updateValue('PAGBANK_CODE_CHALLENGE_D30', $this->getPkceData('D30', 'code_challenge'), false);

		Configuration::updateValue('PAGBANK_PS_SESSION', Tools::getAdminTokenLite('AdminModules'), false);

		$token_cron = $this->getTokenHash();
		
		if (_PS_VERSION_ >= '1.7.0') {
			$transactions_link = $this->context->link->getAdminLink("AdminPagBank8", false) . '&token=' . Tools::getAdminTokenLite("AdminPagBank8");
			$logs_link = $this->context->link->getAdminLink("AdminPagBank8Logs", false) . '&token=' . Tools::getAdminTokenLite("AdminPagBank8Logs");
		}else{
			$transactions_link = $this->context->link->getAdminLink("AdminPagBank", false) . '&token=' . Tools::getAdminTokenLite("AdminPagBank");
			$logs_link = $this->context->link->getAdminLink("AdminPagBankLogs", false) . '&token=' . Tools::getAdminTokenLite("AdminPagBankLogs");
		}

		$this->context->smarty->assign(array(
			'module_dir' => $this->_path,
			'module_version' => $this->version,
			'transactions_link' => $transactions_link,
			'logs_link' => $logs_link,
			'environment' => $this->environment,
			'new_user_code' => 'prestabr_code_' . $this->environment . '_' . $this->sortRefNumber(),
			'new_user_state_d14' => urlencode(basename(_PS_ADMIN_DIR_) . '/registerUser/D14'),
			'new_user_state_d30' => urlencode(basename(_PS_ADMIN_DIR_) . '/registerUser/D30'),
			'new_user_state_tax' => urlencode(basename(_PS_ADMIN_DIR_) . '/registerUser/TAX'),
			'client_id_tax' => $client_id_tax,
			'client_id_d14' => $client_id_d14,
			'client_id_d30' => $client_id_d30,
			'signin_connect_url' => $signin_connect_url,
			'callback_url' => $this->urls['update'],
			'scope' => 'payments.read+payments.create+payments.refund+accounts.read',
			'code_verifier_tax' => Configuration::get('PAGBANK_CODE_VERIFIER_TAX'),
			'code_challenge_tax' => Configuration::get('PAGBANK_CODE_CHALLENGE_TAX'),
			'code_verifier_d14' => Configuration::get('PAGBANK_CODE_VERIFIER_D14'),
			'code_challenge_d14' => Configuration::get('PAGBANK_CODE_CHALLENGE_D14'),
			'code_verifier_d30' => Configuration::get('PAGBANK_CODE_VERIFIER_D30'),
			'code_challenge_d30' => Configuration::get('PAGBANK_CODE_CHALLENGE_D30'),
			'authorization_code' => $this->authorization_code,
			'this_page' => $_SERVER['REQUEST_URI'],
			'ps_version' => substr(_PS_VERSION_, 0, 3),
			'credential' => Configuration::get('PAGBANK_CREDENTIAL'),
			'api_info' => $this->api_info,
			'app_info_tax' => $app_info_tax,
			'app_info_d14' => $app_info_d14,
			'app_info_d30' => $app_info_d30,
			'tokenTax' => (bool)$tax,
			'tokenD14' => (bool)$d14,
			'tokenD30' => (bool)$d30,
			'token_cron' => $token_cron,
		));

		$this->getConfigFormValues();

		if (!function_exists('curl_init')) {
			$output .= $this->displayError('Este módulo requer CURL ativado no servidor para funcionar corretamente.');
		}
		if ((int)Configuration::get('PS_DISABLE_NON_NATIVE_MODULE') == '1') {
			$output .= $this->displayError('Este módulo requer a execução de Módulos não Nativos.');
		}
		if (
			(int)Configuration::get('PAGBANK_CREDIT_CARD') +
			(int)Configuration::get('PAGBANK_BANKSLIP') +
			(int)Configuration::get('PAGBANK_PIX') +
			(int)Configuration::get('PAGBANK_WALLET') +
			(int)Configuration::get('PAGBANK_GOOGLE_PAY') == 0
		) {
			$output .= $this->displayError('Pelo menos 1 opção de pagamento deve estar ativa para este módulo funcionar.');
		}
		if ((int)Configuration::get('PAGBANK_GOOGLE_PAY') == 1 && strlen(Configuration::get('PAGBANK_GOOGLE_MERCHANT_ID')) <= 12) {
			$output .= $this->displayError('Com o Google Pay ativo é preciso informar o Merchant ID');
		}
		if ((int)Configuration::get('PAGBANK_RECAPTCHA') == 1 && strlen(Configuration::get('PAGBANK_RECAPTCHA_SITE_KEY')) <= 39
			&& strlen(Configuration::get('PAGBANK_RECAPTCHA_API_KEY')) <= 39) {
			$output .= $this->displayError('Com o reCaptcha ativo é preciso informar o Site Key e Api Key');
		}

		$output .= $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');

		return $output . $this->pag_controller->getConfigForm();
	}

	/*
	* Define alguns elementos no header do backoffice
	*/
	public function hookDisplayBackOfficeHeader()
	{
		$this->context->controller->addCSS($this->_path . 'css/pagbank_admin.css');
		$this->context->controller->addJS($this->_path . 'js/mascara.js');
		$this->callRefreshToken();

		if (_PS_VERSION_ < '9.0.0') {
			$this->checkWarningsAndUpdates();
		}
	}

	public function hookDisplayDashboardTop()
	{
		if (_PS_VERSION_ >= '9.0.0') {
			return $this->checkWarningsAndUpdates();
		}
	}

	public function checkWarningsAndUpdates()
	{
		if(Tools::getValue('controller') === 'AdminModulesManage' || Tools::getValue('controller') === 'AdminModules') {
			if (_PS_VERSION_ >= '1.7.0') {
				if (empty(Configuration::get('PAGBANK_CRON_WARNING'))
					|| Configuration::get('PAGBANK_CRON_WARNING') === 'NULL') {
					$check_cron = true;
				} else {
					$check_cron = false;
				}
				$check_carrier = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('SELECT `id_module` FROM `' . _DB_PREFIX_ . 'module_carrier` WHERE `id_module`=' . $this->id . '');
				if (_PS_VERSION_ >= '9.0.0') {
					$url_carrier = Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . basename(_PS_ADMIN_DIR_) . '/index.php/improve/payment/preferences?_token=' . Tools::getAdminTokenLite('AdminPaymentPreferences');
				} else {
					$url_carrier = 'index.php?controller=AdminPaymentPreferences&token='.Tools::getAdminTokenLite('AdminPaymentPreferences');
				}
			}

			if (empty(Configuration::get('PS_REWRITING_SETTINGS'))
				|| Configuration::get('PS_REWRITING_SETTINGS') === 'NULL') {
				$check_rewriting = true;
				if (_PS_VERSION_ >= '9.0.0') {
					$url_rewriting = Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . basename(_PS_ADMIN_DIR_) . '/index.php/configure/shop/seo-urls/?_token=' . Tools::getAdminTokenLite('AdminShopUrl');
				} else {
					$url_rewriting = 'index.php?controller=AdminMeta&token=' . Tools::getAdminTokenLite('AdminMeta');
				}
			} else {
				$check_rewriting = false;
				$url_rewriting = '';
			}

			$file_version = Tools::file_get_contents('https://raw.githubusercontent.com/pagseguro/pagseguro-modulo-prestashop/master/VERSION');
			if($this->version < $file_version){
				$check_update = true;
			} else {
				$check_update = false;
			}

			if (_PS_VERSION_ >= '9.0.0') {
				$this->context->smarty->assign(array(
					'check_cron' => $check_cron,
					'check_carrier' => $check_carrier,
					'check_rewriting' => $check_rewriting,
					'check_update' => $check_update,
					'url_carrier' => $url_carrier,
					'url_rewriting' => $url_rewriting,
					'file_version' => $file_version
				));
				return $this->display(__FILE__, 'views/templates/admin/info.tpl');
			} else {
				if (_PS_VERSION_ >= '1.7.0' && _PS_VERSION_ < '9.0.0') {
					if ($check_cron) {
						$this->context->controller->warnings[] = '<p><b>Módulo PagBank - Tarefa Cron: </b></p> <p>As URLs de Tarefa Cron mudaram. 
						Por favor, verifique e atualize em seu servidor de hospedagem. <br /> 
						Para remover este alerta acesse as configurações do módulo em "Debug & Logs" e marque a opção "Desativar aviso Cron?".</p>';
					}
				}
				if (isset($check_carrier) && empty($check_carrier)) {
					$this->context->controller->warnings[] = '<p><b>Módulo PagBank - Restrições de transportadora: </b></p> 
					<p>Verifique se as transportadoras estão vinculadas à forma de pagamento. 
					Isso vai garantir que o módulo seja exibido e esteja disponível para processar pagamentos na tela de checkout. 
					Para ver as configurações de Restrições de transportadora <u><a href="' . $url_carrier . '">Clique aqui</a></u> (role até o final da página)</p>';
				}
				if ($check_rewriting) {
					$this->context->controller->warnings[] = '<p><b>Módulo PagBank - URL Amigável: </b></p> 
					<p>Ative a opção de reescrita de url para que o módulo possa funcionar corretamente. 
					Para ativar a URL Amigável <u><a href="' . $url_rewriting . '">Clique aqui</a></u></p>';
				}
				if ($check_update) {
					$this->context->controller->warnings[] = '<p><b>Módulo PagBank - Atualização disponível! Nova Versão: v.'.$file_version.' <br /> 
					Acesse: <a href="https://github.com/pagseguro/pagseguro-modulo-prestashop" target="_blank">https://github.com/pagseguro/pagseguro-modulo-prestashop</a> </b></p>';
				}
			}
		}
	}

	/*
	* Define alguns elementos no header do front
	*/
	public function hookDisplayHeader()
	{
		if (_PS_VERSION_ >= '1.7.0') {
			if (
				$this->context->controller->php_self === 'order'
				|| $this->context->controller->php_self === 'orderopc'
				|| $this->context->controller->php_self === 'order-opc'
				|| $this->context->controller->php_self === 'order-confirmation'
			) {
				$this->context->controller->registerStylesheet(
					'pagbank-css',
					'modules/' . $this->name . '/css/pagbank.css',
					[
						'media' => 'all',
						'priority' => 150
					]
				);
				$this->context->controller->registerStylesheet(
					'google-font',
					'https://fonts.googleapis.com/css2?family=Inconsolata:wght@400;700&display=swap',
					[
						'server' => 'remote',
						'media' => 'all',
						'priority' => 150
					]
				);
				$this->context->controller->addJqueryPlugin('fancybox');
				$this->context->controller->registerJavascript(
					'pagbank-mascara',
					'modules/' . $this->name . '/js/mascara.js',
					[
						'position' => 'bottom',
						'priority' => 150
					]
				);
				$this->context->controller->registerJavascript(
					'pagbank-clipboard',
					'modules/' . $this->name . '/js/clipboard.min.js',
					[
						'position' => 'bottom',
						'priority' => 150
					]
				);
				$this->context->controller->registerJavascript(
					'pagbank-purify',
					'modules/' . $this->name . '/js/purify.min.js',
					[
						'position' => 'bottom',
						'priority' => 150
					]
				);
				$this->context->controller->registerJavascript(
					'pagbank-min',
					'https://assets.pagseguro.com.br/checkout-sdk-js/rc/dist/browser/pagseguro.min.js',
					[
						'server' => 'remote',
						'media' => 'all',
						'priority' => 150
					]
				);
				$this->context->controller->registerJavascript(
					'pagbank-js',
					'modules/' . $this->name . '/js/pagbank.js',
					[
						'position' => 'bottom',
						'priority' => 150
					]
				);
				if ((int)Configuration::get('PAGBANK_GOOGLE_PAY') == 1 && strlen(Configuration::get('PAGBANK_GOOGLE_MERCHANT_ID')) >= 13) {
					$this->context->controller->registerJavascript(
						'google-pay',
						'https://pay.google.com/gp/p/js/pay.js',
						[
							'server' => 'remote',
							'media' => 'all',
							'priority' => 150
						]
					);
				}
				if ((int)Configuration::get('PAGBANK_RECAPTCHA') == 1 && strlen(Configuration::get('PAGBANK_RECAPTCHA_SITE_KEY')) >= 32
					&& strlen(Configuration::get('PAGBANK_RECAPTCHA_API_KEY')) >= 32) {
					$recaptcha_site_key = trim(Configuration::get('PAGBANK_RECAPTCHA_SITE_KEY'));
					$recaptcha_js = 'https://www.google.com/recaptcha/enterprise.js?render='.$recaptcha_site_key;
					$this->context->controller->registerJavascript(
						'google-recaptcha-v3',
						$recaptcha_js,
						[
							'server' => 'remote',
							'media' => 'all',
							'priority' => 150
						]
					);
				}
			}
		} else {
			if (
				$this->context->controller->php_self === 'order'
				|| $this->context->controller->php_self === 'orderopc'
				|| $this->context->controller->php_self === 'order-opc'
				|| $this->context->controller->php_self === 'order-confirmation'
			) {
				$this->context->controller->addCSS(array(
					$this->_path . 'css/pagbank.css',
					'https://fonts.googleapis.com/css2?family=Inconsolata:wght@400;700&display=swap'
				));
				if ((int)Configuration::get('PAGBANK_GOOGLE_PAY') == 1 && strlen(Configuration::get('PAGBANK_GOOGLE_MERCHANT_ID')) >= 13) {
					$google_pay_js = 'https://pay.google.com/gp/p/js/pay.js';
				} else {
					$google_pay_js = '';
				}
				if ((int)Configuration::get('PAGBANK_RECAPTCHA') == 1 && strlen(Configuration::get('PAGBANK_RECAPTCHA_SITE_KEY')) >= 32
					&& strlen(Configuration::get('PAGBANK_RECAPTCHA_API_KEY')) >= 32) {
					$recaptcha_site_key = trim(Configuration::get('PAGBANK_RECAPTCHA_SITE_KEY'));
					$recaptcha_js = 'https://www.google.com/recaptcha/enterprise.js?render='.$recaptcha_site_key;
				} else {
					$recaptcha_js = '';
				}
				$this->context->controller->addJS(array(
					$this->_path . 'js/mascara.js',
					$this->_path . 'js/clipboard.min.js',
					$this->_path . 'js/purify.min.js',
					'https://assets.pagseguro.com.br/checkout-sdk-js/rc/dist/browser/pagseguro.min.js',
					$this->_path . 'js/pagbank.js',
					$google_pay_js,
					$recaptcha_js
				));
			}
		}
	}

	/* Forma de pagamento ativa */
	public function activePayments()
	{
		return array(
				'credit_card' => (bool)Configuration::get('PAGBANK_CREDIT_CARD'),
				'bankslip' => (bool)Configuration::get('PAGBANK_BANKSLIP'),
				'pix' => (bool)Configuration::get('PAGBANK_PIX'),
				'wallet' => (bool)Configuration::get('PAGBANK_WALLET'),
				'google_pay' => (bool)Configuration::get('PAGBANK_GOOGLE_PAY')
			);
	}

	/* Infos de descontos */
	public function activeDiscounts()
	{
		return array(
				'credit_card' => Configuration::get('PAGBANK_DISCOUNT_CREDIT') > 0 ? (bool)Configuration::get('PAGBANK_DISCOUNT_CREDIT') : false,
				'bankslip' => Configuration::get('PAGBANK_DISCOUNT_BANKSLIP') > 0 ? (bool)Configuration::get('PAGBANK_DISCOUNT_BANKSLIP') : false,
				'pix' => Configuration::get('PAGBANK_DISCOUNT_PIX') > 0 ? (bool)Configuration::get('PAGBANK_DISCOUNT_PIX') : false,
				'wallet' => Configuration::get('PAGBANK_DISCOUNT_WALLET') > 0 ? (bool)Configuration::get('PAGBANK_DISCOUNT_WALLET') : false,
				'google_pay' => Configuration::get('PAGBANK_DISCOUNT_GOOGLE') > 0 ? (bool)Configuration::get('PAGBANK_DISCOUNT_GOOGLE') : false,
				'discount_type' => Configuration::get('PAGBANK_DISCOUNT_TYPE'),
				'discount_value' => Configuration::get('PAGBANK_DISCOUNT_VALUE'),
				'credit_card_value' => $this->calculateDiscounts('credit_card', 1),
				'bankslip_value' => $this->calculateDiscounts('bankslip'),
				'pix_value' => $this->calculateDiscounts('pix'),
				'wallet_value' => $this->calculateDiscounts('wallet'),
				'google_pay_value' => $this->calculateDiscounts('google_pay', 1)
			);
	}

	/*
	 * Exibe as opções de pagamento do módulo na loja, sem redirecionar para um controller novo
	 */
	public function hookDisplayPayment($params)
	{
		if (!$this->active || $this->ready === false) {
			return false;
		}
		$this->paymentLogic($params);

		return $this->display(__FILE__, '/views/templates/v6/hook/payment.tpl');
	}

	/*
	 * Lógica de Pagamento
	 */
	public function paymentLogic($params)
	{
		if (!$this->active || $this->ready === false) {
			return false;
		}
		if (!$this->checkCurrency($params['cart'])) {
			return false;
		}
		$cart = $params['cart'];
		$currency_id = $cart->id_currency;
		$currency = new Currency((int)$currency_id);

		$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
		$customer = new Customer((int)($cart->id_customer));
		$address = new Address((int)($cart->id_address_invoice));
		$firstname = str_replace(' ', ' ', trim($customer->firstname));
		$lastname = str_replace(' ', ' ', trim($customer->lastname));
		$sender_name = trim($firstname . ' ' . $lastname);
		if (isset($customer->birthday) && $customer->birthday != '0000-00-00') {
			$birthday = date('d/m/Y', strtotime($customer->birthday));
			$birthday_string = DateTime::createFromFormat('d/m/Y', $birthday)->format('d/m/Y');
		}
		$phone = isset($address->phone_mobile) && !empty($address->phone_mobile) ? $address->phone_mobile : $address->phone;
		$page_name = $this->context->controller->php_self;
		$method = false;
		if (Tools::isSubmit('method')) {
			$method = Tools::getValue('method');
			if ($method === 'updateCarrierAndGetPayments') {
				$method = true;
			}
		}

		$id_country = (int)$address->id_country;
		if (!$id_country || $id_country < 1) {
			$id_country = Country::getIdByName($this->context->language->id, 'Brasil');
		}
		if (!$id_country || $id_country < 1) {
			$id_country = Country::getIdByName($this->context->language->id, 'Brazil');
		}
		if (!$id_country || $id_country < 1) {
			$id_country = 58;
		}
		$states = State::getStatesByIdCountry($id_country);

		$pix_expiration = Configuration::get('PAGBANK_PIX_TIME_LIMIT');
		$wallet_expiration = Configuration::get('PAGBANK_WALLET_TIME_LIMIT');
		$current_hour = date("H", time());
		$alternate_time = false;
		if (((int)$current_hour > 20 || (int)$current_hour < 6) && (int)$total > 999) {
			$alternate_time = true;
		}

		$active_payments = $this->activePayments();
		$active_discounts = $this->activeDiscounts();

		if ((int)Configuration::get('PAGBANK_TWO_CREDIT_CARD') == 1) {
			$minimum_inst = (int)Configuration::get('PAGBANK_MINIMUM_INSTALLMENTS');
			$minimun_val = round(($total/2), 2, PHP_ROUND_HALF_DOWN);
			$minimum_inst_f = number_format(round($minimum_inst), 2, ',', '');
			if ($minimun_val >= $minimum_inst) {
				$pay_two_card_enable = 1;
			} else {
				$pay_two_card_enable = 0;
			}
		} else {
			$pay_two_card_enable = 0;
		}

		$this->smarty->assign(array(
			'card_value_pagbank' => number_format($total, 2, '', ''),
			'total_pagbank' => number_format($total, 2, '.', ''),
			'total_min_pagbank' => isset($minimum_inst_f) && $minimum_inst_f != '' ? $minimum_inst_f : '',
			'page_name' => $page_name,
			'active_payments' => $active_payments,
			'active_discounts' => $active_discounts,
			'save_credit_card' => (int)Configuration::get('PAGBANK_SAVE_CREDIT_CARD'),
			'pay_two_card_enable' => $pay_two_card_enable,
			'device' => $this->device,
			'tpl_dir' => _PS_MODULE_DIR_ . $this->name . '/views/templates/v6/hook',
			'currency' => $currency,
			'checkout' => (bool)Configuration::get('PS_ORDER_PROCESS_TYPE'),
			'pix_timeout' => $this->calculateDeadline((int)$pix_expiration),
			'wallet_timeout' => $this->calculateDeadline((int)$wallet_expiration),
			'alternate_time' => $alternate_time,
			'bankslip_date_limit' => (int)Configuration::get('PAGBANK_BANKSLIP_DATE_LIMIT'),
			'bankslip_text' => Configuration::get('PAGBANK_BANKSLIP_TEXT'),
			'phone' => $phone,
			'method' => $method,
			'address_invoice' => $address,
			'number_invoice' => $address->{$this->number_field},
			'compl_invoice' => $address->{$this->compl_field},
			'states' => $states,
			'sender_name' => $sender_name,
			'birthday' => isset($birthday_string) && $birthday_string != '' ? $birthday_string : '',
			'customer_token' => $this->getCustomerToken((int)($cart->id_customer)),
			'ps_version' => _PS_VERSION_,
			'img_path' => $this->urls['img']
		));
	}


	/*
	 * Exibe as opções de pagamento do módulo na loja, sem redirecionar para um controller novo
	 */
	public function hookPaymentOptions($params)
	{
		if (!$this->active || $this->ready === false) {
			return false;
		}

		$this->paymentLogic($params);

		$pay_options = array();
		$pay_active = $this->activePayments();

		if ($pay_active['credit_card']) {
			$pay_text = 'Cartão de Crédito'.$this->messageDiscounts('credit_card');
			$pay_tpl = 'credit_card.tpl';
			$ps_option = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
			$ps_option->setModuleName($this->name)
				->setCallToActionText($pay_text)
				->setLogo($this->urls['img'] . 'pagbank-logo-animado_35px.gif')
				->setAction($this->context->link->getModuleLink($this->name, 'validation', array('ptype' => 'credit_card'), true))
				->setForm($this->fetch('module:pagbank/views/templates/v8/hook/' . $pay_tpl));
			$pay_options[] = $ps_option;
		}

		if ($pay_active['google_pay'] && strlen(Configuration::get('PAGBANK_GOOGLE_MERCHANT_ID')) >= 13 ) {
			$pay_text = 'Google Pay'.$this->messageDiscounts('google_pay');
			$pay_tpl = 'google_pay.tpl';
			$ps_option = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
			$ps_option->setModuleName($this->name)
				->setCallToActionText($pay_text)
				->setLogo($this->urls['img'] . 'pagbank-logo-animado_35px.gif')
				->setAction($this->context->link->getModuleLink($this->name, 'validation', array('ptype' => 'google_pay'), true))
				->setForm($this->fetch('module:pagbank/views/templates/v8/hook/' . $pay_tpl));
			$pay_options[] = $ps_option;
		}

		if ($pay_active['pix']) {
			$pay_text = 'Pix'.$this->messageDiscounts('pix');
			$pay_tpl = 'pix.tpl';
			$ps_option = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
			$ps_option->setModuleName($this->name)
				->setCallToActionText($pay_text)
				->setLogo($this->urls['img'] . 'pagbank-logo-animado_35px.gif')
				->setAction($this->context->link->getModuleLink($this->name, 'validation', array('ptype' => 'pix'), true))
				->setForm($this->fetch('module:pagbank/views/templates/v8/hook/' . $pay_tpl));
			$pay_options[] = $ps_option;
		}

		if ($pay_active['bankslip']) {
			$pay_text = 'Boleto'.$this->messageDiscounts('bankslip');
			$pay_tpl = 'bankslip.tpl';
			$ps_option = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
			$ps_option->setModuleName($this->name)
				->setCallToActionText($pay_text)
				->setLogo($this->urls['img'] . 'pagbank-logo-animado_35px.gif')
				->setAction($this->context->link->getModuleLink($this->name, 'validation', array('ptype' => 'bankslip'), true))
				->setForm($this->fetch('module:pagbank/views/templates/v8/hook/' . $pay_tpl));
			$pay_options[] = $ps_option;
		}

		if ($pay_active['wallet']) {
			$pay_text = 'Pagar com PagBank'.$this->messageDiscounts('wallet');
			$pay_tpl = 'wallet.tpl';
			$ps_option = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
			$ps_option->setModuleName($this->name)
				->setCallToActionText($pay_text)
				->setLogo($this->urls['img'] . 'pagbank-logo-animado_35px.gif')
				->setAction($this->context->link->getModuleLink($this->name, 'validation', array('ptype' => 'wallet'), true))
				->setForm($this->fetch('module:pagbank/views/templates/v8/hook/' . $pay_tpl));
			$pay_options[] = $ps_option;
		}

		return $pay_options;
	}


	/*
	 * Exibe mensagens de confirmação e de erro na parte superior da página de pagamento
	 */
	public function hookDisplayPaymentTop($params)
	{
		if (Tools::getIsset('pagbank_msg') && Tools::getIsset('pagbank_msg') !== '') {
			$pagbank_msg = Tools::getValue('pagbank_msg');
		} else {
			$pagbank_msg = $this->context->cookie->pagbank_msg;
		}

		if (!$this->active || (!$this->checkCurrency($params['cart'])) || $this->ready === false) {
			$pagbank_msg = $this->l('PagBank: Módulo não disponível. Por favor, verifique se o mesmo está ativo e cheque as Configurações do App.
			Este módulo só é compatível com a moeda BRL.');
		}

		$this->callRefreshToken();

		$cart = $params['cart'];
		$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
		$msg_console = (int)Configuration::get('PAGBANK_SHOW_CONSOLE');
		$active_payments = $this->activePayments();
		$active_discounts = $this->activeDiscounts();

		$this->context->smarty->assign(array(
			'pagbank_msg' => $pagbank_msg,
			'public_key' => $this->public_key,
			'msg_console' => $msg_console,
			'active_payments' => $active_payments,
			'active_discounts' => $active_discounts,
			'two_card_inst' => Configuration::get('PAGBANK_TWO_CREDIT_CARD_INST'),
			'shop_name' => Configuration::get('PS_SHOP_NAME'),
			'max_installments' => (int)Configuration::get('PAGBANK_MAX_INSTALLMENTS'),
			'installments_min_value' => (int)Configuration::get('PAGBANK_MINIMUM_INSTALLMENTS'),
			'installments_min_type' => (int)Configuration::get('PAGBANK_INSTALLMENTS_TYPE'),
			'account_id' => $this->account_id,
			'google_merchant_id' => trim(Configuration::get('PAGBANK_GOOGLE_MERCHANT_ID')),
			'google_environment' => $this->google_environment,
			'recaptcha' => (int)Configuration::get('PAGBANK_RECAPTCHA'),
			'recaptcha_site_key' => trim(Configuration::get('PAGBANK_RECAPTCHA_SITE_KEY')),
			'device' => $this->device,
			'ps_version' => substr(_PS_VERSION_, 0, 3),
			'pagbank_version' => $this->version,
			'total_pagbank' => number_format($total, 2, '.', ''),
			'img_path' => $this->urls['img'],
			'url_update' => Context::getContext()->link->getModuleLink($this->name, 'update', ['ajax' => true])
		));

		$this->context->cookie->pagbank_msg = false;

		if (_PS_VERSION_ >= '1.7.0') {
			return $this->display(__FILE__, '/views/templates/v8/hook/payment_top.tpl');
		} else {
			return $this->display(__FILE__, '/views/templates/v6/hook/payment_top.tpl');
		}
	}

	/*
	 * Exibe a página de confirmação de pagamento com os parâmetros do pedido na loja e no pagbank
	 */
	public function hookDisplayPaymentReturn($params)
	{
		if (!$this->active || $this->ready === false) {
			return false;
		}

		$id_cart = Tools::getValue('id_cart');
		$id_order = Tools::getValue('id_order');
		$order = new Order($id_order);

		$info = $this->getOrderData($id_cart, 'id_cart');
		$cod_status = $info['status'];
		$transaction_code = $info['transaction_code'];

		$transaction = $this->getTransaction($transaction_code, $id_cart);
		if (isset($transaction->charges)) {
			$payment = end($transaction->charges);
			$payment_type = $payment->payment_method->type;
			$payment_status = $payment->status;

			if ($cod_status != $payment_status) {
				$this->updateOrderStatus($cod_status, $id_order, date("Y-m-d H:i:s"));
			}
		} else {
			$payment_status = 'WAITING';
			if (isset($transaction->qr_codes) && $transaction->qr_codes[0]->arrangements[0] === 'PIX') {
				$pix = array();
				$payment_type = 'PIX';
				$pix_expiration = Configuration::get('PAGBANK_PIX_TIME_LIMIT');
				$qr = end($transaction->qr_codes);
				$pix['id'] = $qr->id;
				$pix['text'] = $qr->text;
				$pix['deadline'] = $this->calculateDeadline($pix_expiration);
				$pix['expiration_date'] = $qr->expiration_date;
				foreach ($qr->links as $qr_link) {
					if ($qr_link->media === 'image/png') {
						$pix['link'] = $qr_link->href;
					}
				}
			} elseif (isset($transaction->qr_codes) && $transaction->qr_codes[0]->arrangements[0] === 'PAGBANK' || 
			isset($transaction->deep_links) && $transaction->deep_links[0]->url){
				$wallet = array();
				$payment_type = 'WALLET';
				$wallet_expiration = Configuration::get('PAGBANK_WALLET_TIME_LIMIT');
				if(isset($transaction->qr_codes) && $transaction->qr_codes[0]->arrangements[0] === 'PAGBANK'){
					$qr = end($transaction->qr_codes);
					$wallet['id'] = $qr->id;
					$wallet['text'] = $qr->text;
					$wallet['deadline'] = $this->calculateDeadline($wallet_expiration);
					$wallet['expiration_date'] = $qr->expiration_date;
					foreach ($qr->links as $qr_link) {
						if ($qr_link->media === 'image/png') {
							$wallet['link'] = $qr_link->href;
						}
					}
				} else {
					$wallet['deadline'] = $this->calculateDeadline($wallet_expiration);
					$wallet['expiration_date'] = date(DATE_ATOM, strtotime("+{$wallet_expiration} minutes"));
					$wallet['link'] = $transaction->deep_links[0]->url;
				}
			}
		}

		$current_hour = date("H", time());

		$alternate_time = false;
		if (((int)$current_hour > 20 || (int)$current_hour < 6) && $order->total_paid > 999) {
			$alternate_time = true;
		}

		$customer_name = $this->context->customer->firstname;
		$msg_console = (int)Configuration::get('PAGBANK_SHOW_CONSOLE');

		$this->smarty->assign(array(
			'msg_console' => $msg_console,
			'device' => $this->device,
			'ps_version' => _PS_VERSION_,
			'customer_name' => $customer_name,
			'info' => $info,
			'pay_link' => isset($info['url']) && $info['url'] != '' ? $info['url'] : false,
			'transaction_code' => $transaction_code,
			'order_products' => $order->getProducts(),
			'transaction' => $transaction,
			'payment_status' => $this->parseStatus($payment_status),
			'pix' => isset($pix) && is_array($pix) ? $pix : false,
			'wallet' => isset($wallet) && is_array($wallet) ? $wallet : false,
			'current_hour' => $current_hour,
			'alternate_time' => $alternate_time,
			'payment_type' => isset($payment_type) && $payment_type != '' ? $payment_type : false,
			'order' => $order,
			'currency' => new Currency($this->context->currency->id),
			'paid_state' => Configuration::get('PAGBANK_PAID'),
			'img_path' => $this->urls['img'],
			'url_update' => Context::getContext()->link->getModuleLink($this->name, 'update', ['ajax' => true])
		));

		if (_PS_VERSION_ >= '1.7.0') {
			return $this->display(__FILE__, '/views/templates/v8/hook/payment_return.tpl');
		} else {
			return $this->display(__FILE__, '/views/templates/v6/hook/payment_return.tpl');
		}
	}

	/*
	 * Exibe os dados do pedido no pagbank na aba de detalhes do pedido no BackOffice
	 */
	public function hookDisplayAdminOrder()
	{
		if (!$this->active) {
			return;
		}

		$id_order = Tools::getValue('id_order');
		$order = new Order((int)$id_order);
		$info = $this->getOrderData($order->id_cart, 'id_cart');

		if (!$info) {
			return;
		}

		$transaction = $this->getTransaction($info['transaction_code'], $order->id_cart);
		$status_pagbank = $info['status'];
		$payment_description = $info['payment_description'];

		if (Tools::isSubmit('refundOrderPagBank')) {
			if (in_array($status_pagbank, array('AUTHORIZED', 'PAID', 'AVAILABLE', 'DISPUTE'))) {
				$charge_option = Tools::getValue('charge_option');
				if ((int)$charge_option == 1) {
					$transaction_charge = str_replace('CHAR_', '', $transaction->charges[0]->id);
				} else {
					$transaction_charge = str_replace('CHAR_', '', $transaction->charges[1]->id);
				}
				$formatted = preg_replace('/\D/', '', Tools::getValue('refund_value'));
				if ((int)$formatted > 0) {
					$clean_value = $formatted;
				} else {
					if ((int)$charge_option == 1) {
						$clean_value = $transaction->charges[0]->amount->value;
					} else {
						$clean_value = $transaction->charges[1]->amount->value;
					}
				}
				$api_response = $this->refundTransaction($transaction_charge, $clean_value, $order, $info['transaction_code']);
				if (isset($api_response) && $api_response === true) {
					$this->context->smarty->assign(array(
						'pagbank_msg' => $this->l('Pagamento Estornado no PagBank.'),
						'reload' => 1
					));
				} else {
					$this->context->smarty->assign('pagbank_msg', $this->l('Erro ao tentar Estornar o Pedido no PagBank.'));
				}
			} else {
				$this->context->smarty->assign('pagbank_msg', $this->l('Status do Pedido no PagBank não permite Estorno.'));
			}
		}

		if (Tools::isSubmit('captureOrderPagBank')) {
			if ($status_pagbank === 'AUTHORIZED') {
				$charge_option = Tools::getValue('charge_option');
				if ((int)$charge_option == 1) {
					$transaction_charge = str_replace('CHAR_', '', $transaction->charges[0]->id);
				} else {
					$transaction_charge = str_replace('CHAR_', '', $transaction->charges[1]->id);
				}
				$formatted = preg_replace('/\D/', '', Tools::getValue('capture_value'));
				if ((int)$formatted > 0) {
					$clean_value = $formatted;
				} else {
					if ((int)$charge_option == 1) {
						$clean_value = $transaction->charges[0]->amount->value;
					} else {
						$clean_value = $transaction->charges[1]->amount->value;
					}
				}
				$api_response = $this->captureTransaction($transaction_charge, $clean_value, $order, $info['transaction_code']);
				if (isset($api_response) && $api_response === true) {
					$this->context->smarty->assign(array(
						'pagbank_msg' => $this->l('Pagamento Capturado no PagBank.'),
						'reload' => 1
					));
				} else {
					$this->context->smarty->assign('pagbank_msg', $this->l('Erro ao tentar Capturar o Pagamento no PagBank.'));
				}
			} else {
				$this->context->smarty->assign('pagbank_msg', $this->l('Status do Pedido no PagBank não permite Captura.'));
			}
		}

		$this->context->smarty->assign(array(
			'device' => $this->device,
			'order' => $order,
			'transaction' => $transaction,
			'payment_description' => $payment_description,
			'info' => $info,
			'version' => _PS_VERSION_,
			'status' => $status_pagbank,
			'desc_status' => $this->parseStatus($status_pagbank),
			'currency' => new Currency($this->context->currency->id),
			'this_page' => $_SERVER['REQUEST_URI']
		));

		if (_PS_VERSION_ >= '1.7.0') {
			return $this->display(__FILE__, '/views/templates/v8/hook/admin_order.tpl');
		} else {
			return $this->display(__FILE__, '/views/templates/v6/hook/admin_order.tpl');
		}
	}

	/*
	 * Valida a moeda do cliente na loja
	 */
	public function checkCurrency($cart)
	{
		$currency_order = new Currency($cart->id_currency);
		$currencies_module = $this->getCurrency($cart->id_currency);

		if (is_array($currencies_module)) {
			foreach ($currencies_module as $currency_module) {
				if ($currency_order->id == $currency_module['id_currency']) {
					return true;
				}
			}
		}
		return false;
	}

	/*
	 * Verifica a credencial utilizada p/ consultas
	 */
	public function currentCredential($credential = false, $environment = false)
	{
		if($credential){
			$credential_type = $credential;
		} else {
			$credential_type = $this->credential_type;
		}
		
		if ($environment == 1 || $environment === '' || $environment === 'null') {
			$token_code = Configuration::get('PAGBANK_TOKEN_'.$credential_type.'');
		} else {
			$token_code = Configuration::get('PAGBANK_TOKEN_SANDBOX_'.$credential_type.'');
		}

		return $token_code;
	}

	/* 
	 * Pega os dados dos campos de configuração do módulo
	 */
	public function getConfigFormValues()
	{
		return array(
			'PAGBANK_ENVIRONMENT' => Tools::getValue('PAGBANK_ENVIRONMENT', Configuration::get('PAGBANK_ENVIRONMENT')),
			'PAGBANK_CREDENTIAL' => Tools::getValue('PAGBANK_CREDENTIAL', Configuration::get('PAGBANK_CREDENTIAL')),

			'PAGBANK_CREDIT_CARD' => Tools::getValue('PAGBANK_CREDIT_CARD', Configuration::get('PAGBANK_CREDIT_CARD')),
			'PAGBANK_SAVE_CREDIT_CARD' => Tools::getValue('PAGBANK_SAVE_CREDIT_CARD', Configuration::get('PAGBANK_SAVE_CREDIT_CARD')),
			'PAGBANK_TWO_CREDIT_CARD' => Tools::getValue('PAGBANK_TWO_CREDIT_CARD', Configuration::get('PAGBANK_TWO_CREDIT_CARD')),
			'PAGBANK_TWO_CREDIT_CARD_INST' => Tools::getValue('PAGBANK_TWO_CREDIT_CARD_INST', Configuration::get('PAGBANK_TWO_CREDIT_CARD_INST')),
			'PAGBANK_CAPTURE_METHOD' => Tools::getValue('PAGBANK_CAPTURE_METHOD', Configuration::get('PAGBANK_CAPTURE_METHOD')),
			'PAGBANK_MAX_INSTALLMENTS' => Tools::getValue('PAGBANK_MAX_INSTALLMENTS', Configuration::get('PAGBANK_MAX_INSTALLMENTS')),
			'PAGBANK_NO_INTEREST' => Tools::getValue('PAGBANK_NO_INTEREST', Configuration::get('PAGBANK_NO_INTEREST')),
			'PAGBANK_MINIMUM_INSTALLMENTS' => Tools::getValue('PAGBANK_MINIMUM_INSTALLMENTS', Configuration::get('PAGBANK_MINIMUM_INSTALLMENTS')),
			'PAGBANK_INSTALLMENTS_TYPE' => Tools::getValue('PAGBANK_INSTALLMENTS_TYPE', Configuration::get('PAGBANK_INSTALLMENTS_TYPE')),
			'PAGBANK_BANKSLIP' => Tools::getValue('PAGBANK_BANKSLIP', Configuration::get('PAGBANK_BANKSLIP')),
			'PAGBANK_BANKSLIP_DATE_LIMIT' => Tools::getValue('PAGBANK_BANKSLIP_DATE_LIMIT', Configuration::get('PAGBANK_BANKSLIP_DATE_LIMIT')),
			'PAGBANK_BANKSLIP_TEXT' => Tools::getValue('PAGBANK_BANKSLIP_TEXT', Configuration::get('PAGBANK_BANKSLIP_TEXT')),
			'PAGBANK_PIX' => Tools::getValue('PAGBANK_PIX', Configuration::get('PAGBANK_PIX')),
			'PAGBANK_PIX_TIME_LIMIT' => Tools::getValue('PAGBANK_PIX_TIME_LIMIT', Configuration::get('PAGBANK_PIX_TIME_LIMIT')),
			'PAGBANK_WALLET' => Tools::getValue('PAGBANK_WALLET', Configuration::get('PAGBANK_WALLET')),
			'PAGBANK_GOOGLE_PAY' => Tools::getValue('PAGBANK_GOOGLE_PAY', Configuration::get('PAGBANK_GOOGLE_PAY')),
			'PAGBANK_GOOGLE_ENVIRONMENT' => Tools::getValue('PAGBANK_GOOGLE_ENVIRONMENT', Configuration::get('PAGBANK_GOOGLE_ENVIRONMENT')),
			'PAGBANK_GOOGLE_ORDER_DEMO' => Tools::getValue('PAGBANK_GOOGLE_ORDER_DEMO', Configuration::get('PAGBANK_GOOGLE_ORDER_DEMO')),
			'PAGBANK_GOOGLE_MERCHANT_ID' => Tools::getValue('PAGBANK_GOOGLE_MERCHANT_ID', Configuration::get('PAGBANK_GOOGLE_MERCHANT_ID')),

			'PAGBANK_RECAPTCHA' => Tools::getValue('PAGBANK_RECAPTCHA', Configuration::get('PAGBANK_RECAPTCHA')),
			'PAGBANK_RACAPTCHA_CRITERIA' => Tools::getValue('PAGBANK_RACAPTCHA_CRITERIA', Configuration::get('PAGBANK_RACAPTCHA_CRITERIA')),
			'PAGBANK_RECAPTCHA_SITE_KEY' => Tools::getValue('PAGBANK_RECAPTCHA_SITE_KEY', Configuration::get('PAGBANK_RECAPTCHA_SITE_KEY')),
			'PAGBANK_RECAPTCHA_API_KEY' => Tools::getValue('PAGBANK_RECAPTCHA_API_KEY', Configuration::get('PAGBANK_RECAPTCHA_API_KEY')),
			'PAGBANK_RECAPTCHA_URL' => Tools::getValue('PAGBANK_RECAPTCHA_URL', Configuration::get('PAGBANK_RECAPTCHA_URL')),

			'PAGBANK_PAID' => Tools::getValue('PAGBANK_PAID', Configuration::get('PAGBANK_PAID')),
			'PAGBANK_AUTHORIZED' => Tools::getValue('PAGBANK_AUTHORIZED', Configuration::get('PAGBANK_AUTHORIZED')),
			'PAGBANK_CANCELED' => Tools::getValue('PAGBANK_CANCELED', Configuration::get('PAGBANK_CANCELED')),
			'PAGBANK_REFUNDED' => Tools::getValue('PAGBANK_REFUNDED', Configuration::get('PAGBANK_REFUNDED')),
			'PAGBANK_IN_ANALYSIS' => Tools::getValue('PAGBANK_IN_ANALYSIS', Configuration::get('PAGBANK_IN_ANALYSIS')),
			'PAGBANK_AWAITING_PAYMENT' => Tools::getValue('PAGBANK_AWAITING_PAYMENT', Configuration::get('PAGBANK_AWAITING_PAYMENT')),

			'PAGBANK_DISCOUNT_TYPE' => Tools::getValue('PAGBANK_DISCOUNT_TYPE', Configuration::get('PAGBANK_DISCOUNT_TYPE')),
			'PAGBANK_DISCOUNT_VALUE' => Tools::getValue('PAGBANK_DISCOUNT_VALUE', Configuration::get('PAGBANK_DISCOUNT_VALUE')),
			'PAGBANK_DISCOUNT_CREDIT' => Tools::getValue('PAGBANK_DISCOUNT_CREDIT', Configuration::get('PAGBANK_DISCOUNT_CREDIT')),
			'PAGBANK_DISCOUNT_BANKSLIP' => Tools::getValue('PAGBANK_DISCOUNT_BANKSLIP', Configuration::get('PAGBANK_DISCOUNT_BANKSLIP')),
			'PAGBANK_DISCOUNT_PIX' => Tools::getValue('PAGBANK_DISCOUNT_PIX', Configuration::get('PAGBANK_DISCOUNT_PIX')),
			'PAGBANK_DISCOUNT_GOOGLE' => Tools::getValue('PAGBANK_DISCOUNT_GOOGLE', Configuration::get('PAGBANK_DISCOUNT_GOOGLE')),

			'PAGBANK_CRON_WARNING' => Tools::getValue('PAGBANK_CRON_WARNING', Configuration::get('PAGBANK_CRON_WARNING')),
			'PAGBANK_SHOW_CONSOLE' => Tools::getValue('PAGBANK_SHOW_CONSOLE', Configuration::get('PAGBANK_SHOW_CONSOLE')),
			'PAGBANK_FULL_LOG' => Tools::getValue('PAGBANK_FULL_LOG', Configuration::get('PAGBANK_FULL_LOG')),
			'PAGBANK_DELETE_DB' => Tools::getValue('PAGBANK_DELETE_DB', Configuration::get('PAGBANK_DELETE_DB')),

		);
	}

	/*
	 * Atualiza os campos de configuração do módulo
	*/
	protected function postProcess()
	{
		$form_values = $this->getConfigFormValues();

		$erro = false;
		$env_post = (int)Tools::getValue('PAGBANK_ENVIRONMENT');
		$env_banco = (int)Configuration::get('PAGBANK_ENVIRONMENT');
		$cred_post = Tools::getValue('PAGBANK_CREDENTIAL');
		$cred_banco = Configuration::get('PAGBANK_CREDENTIAL');

		foreach (array_keys($form_values) as $key) {
			if ($key === 'PAGBANK_CREDENTIAL' && $env_post != $env_banco) {
				Configuration::updateValue('PAGBANK_CREDENTIAL', '');
			} elseif ($key === 'PAGBANK_CREDENTIAL' && $cred_post != $cred_banco) {
				Configuration::updateValue('PAGBANK_CREDENTIAL', $cred_post);
				$this->getPublicKey();
			} else {
				if (!Configuration::updateValue($key, Tools::getValue($key))) {
					$erro = true;
				}
			}
		}

		if ($erro) {
			return false;
		} else {
			return true;
		}
	}

	/* 
	 * Adiciona Status do PagBank. 
	 * Podem ser utilizados ou alterados na configuração do módulo 
	 */
	public function addStatus()
	{
		return $this->pag_controller->addStatus();
	}

	/* 
	 * Adiciona Status do PagBank. 
	 * Podem ser utilizados ou alterados na configuração do módulo 
	 */
	public function deleteStatus()
	{
		Db::getInstance()->execute("
			UPDATE `" . _DB_PREFIX_ . "order_state` SET `deleted` = 1, `hidden` = 1 WHERE `module_name` = '" . $this->name . "'
		");
		return true;
	}

	/* 
	 * Pega dados do pedido no banco
	 */
	public function getApiInfo($env, $app)
	{
		$result = Db::getInstance()->getRow("
			SELECT `id_api_credential`, `environment`, `app`, `credit_tax`, `bankslip_tax`, `pix_tax`, `client_id`, `cipher_text`, `date_add`
			FROM `" . _DB_PREFIX_ . "pagbank_api_credentials`
			WHERE `environment` = " . pSQL($env) . " AND `app` = '" . pSQL($app) . "'
		");
		return $result;
	}

	/* 
	 * Pega dados do pedido no banco
	 */
	public function getOrderData($id_op, $field)
	{
		$result = Db::getInstance()->getRow("
			SELECT * FROM `" . _DB_PREFIX_ . "pagbank`
			WHERE `" . pSQL($field) . "` = '" . pSQL($id_op) . "'
			ORDER BY `id_pagbank` DESC
		");
		return $result;
	}

	/* 
	 * Atualiza dados do pedido no banco
	 */
	public function updatePagBankData($data)
	{
		$updateQuery = 'UPDATE `' . _DB_PREFIX_ . 'pagbank` SET ';
		if (isset($data['status']) && $data['status'] != "") {
			$updateQuery .= '`status` = "' . pSQL($data['status']) . '", ';
		}
		if (isset($data['status_description']) && $data['status_description'] != "") {
			$updateQuery .= '`status_description` = "' . pSQL($data['status_description']) . '", ';
		}
		if (isset($data['date_upd']) && $data['date_upd'] != "") {
			$updateQuery .= '`date_upd` = "' . pSQL($data['date_upd']) . '" ';
		} else {
			$updateQuery .= '`date_upd` = "' . date("Y-m-d H:i:s") . '" ';
		}
		$updateQuery .= ' WHERE `transaction_code` = "' . pSQL($data['transaction_code']) . '"';
		if (!Db::getInstance()->execute($updateQuery)) {
			$this->saveLog('error', 'update', false, $updateQuery, 'Pedido nao atualizado no banco.');
			return false;
		}
		return true;
	}

	/* 
	 * Insere dados do pedido no banco
	 */
	public function insertPagBankData($data)
	{
		if ($this->getOrderData($data['transaction_code'], 'transaction_code')) {
			return $this->updatePagBankData($data);
		} else {
			foreach ($data as $k => $item) {
				if ($k != 'id_order') {
					if (!$data[$k] || $data[$k] === false) {
						$data[$k] = '';
					}
				}
			}
			if($data['payment_type'] == "CREDIT_CARD") {
				$capture = (int)Configuration::get('PAGBANK_CAPTURE_METHOD');
			} else {
				$capture = 1;
			}
			$ins_query = 'INSERT INTO `' . _DB_PREFIX_ . 'pagbank` 
			(`id_shop`, 
			`id_customer`, 
			`cpf_cnpj`, 
			`id_cart`, 
			`id_order`, 
			`reference`, 
			`transaction_code`, 
			`buyer_ip`, 
			`status`, 
			`status_description`, 
			`payment_type`, 
			`payment_description`, 
			`installments`, 
			`installments_two`, 
			`nsu`, 
			`nsu_two`, 
			`url`, 
			`credential`, 
			`capture`, 
			`environment`, 
			`date_add`, 
			`date_upd`)';
			$ins_query .= ' VALUES 
			(' . (int)$this->shop_id . ', 
			"' . (int)$data['id_customer'] . '", 
			"' . pSQL($data['cpf_cnpj']) . '", 
			' . (int)$data['id_cart'] . ', 
			' . (int)$data['id_order'] . ', 
			"' . pSQL($data['reference']) . '", 
			"' . pSQL($data['transaction_code']) . '", 
			"' . pSQL($data['buyer_ip']) . '", 
			"' . pSQL($data['status']) . '", 
			"' . pSQL($data['status_description']) . '", 
			"' . pSQL($data['payment_type']) . '", 
			"' . pSQL($data['payment_description']) . '", 
			' . (int)$data['installments'] . ', 
			' . (int)$data['installments_two'] . ', 
			"' . pSQL($data['nsu']) . '", 
			"' . pSQL($data['nsu_two']) . '", 
			"' . pSQL($data['url']) . '", 
			"' . pSQL($this->credential_type) . '", 
			"' . (int)$capture . '", 
			"' . (int)$this->environment . '", 
			"' . pSQL($data['date_add']) . '", 
			"' . date("Y-m-d H:i:s") . '")';
			$insert = Db::getInstance()->execute($ins_query);
			if (!$insert || (bool)$insert !== true) {
				$this->saveLog('error', 'insertPagBankData', $data['id_cart'], $ins_query, 'Pedido nao inserido no banco.');
				return false;
			}
			return true;
		}
	}

	/*
	 * Verifica qual forma de pagamento está com o desconto ativo
	*/
	public function checkDiscounts()
	{
		$discount_options = [];
		if ((int)Configuration::get('PAGBANK_DISCOUNT_CREDIT') == 1) {
			$discount_options[] = 'credit_card';
		}
		if ((int)Configuration::get('PAGBANK_DISCOUNT_BANKSLIP') == 1) {
			$discount_options[] = 'bankslip';
		}
		if ((int)Configuration::get('PAGBANK_DISCOUNT_PIX') == 1) {
			$discount_options[] = 'pix';
		}
		if ((int)Configuration::get('PAGBANK_DISCOUNT_WALLET') == 1) {
			$discount_options[] = 'wallet';
		}
		if ((int)Configuration::get('PAGBANK_DISCOUNT_GOOGLE') == 1) {
			$discount_options[] = 'google_pay';
		}

		return $discount_options;
	}

	/*
	 * Calcula descontos antes de gerar o pedido
	*/
	public function calculateDiscounts($payment_type, $installment = false)
	{
		$discount_options = $this->checkDiscounts();
		$discount_type = Configuration::get('PAGBANK_DISCOUNT_TYPE');
		$discount_value = (float)Configuration::get('PAGBANK_DISCOUNT_VALUE');
		$total_products = $this->context->cart->getOrderTotal(true, Cart::ONLY_PRODUCTS);
		$total_shipping = $this->context->cart->getOrderTotal(true, Cart::ONLY_SHIPPING);
		$total_discounts = $this->context->cart->getOrderTotal(true, Cart::ONLY_DISCOUNTS);
		$total_wrapping = $this->context->cart->getOrderTotal(true, Cart::ONLY_WRAPPING);

		if (in_array($payment_type, $discount_options) && $discount_type >= 1 && $discount_value >= 1) {
			if($payment_type === 'credit_card' && $installment == 1 || $payment_type != 'credit_card'
			|| $payment_type === 'google_pay' && $installment == 1 || $payment_type != 'google_pay') {
				if ($discount_type == 1) {
					$total_partial = ($total_products - ($total_discounts + ($total_products * $discount_value / 100)));
				} else {
					$total_partial = (($total_products - $total_discounts) - $discount_value);
				}
				$total_paid = round(($total_partial + $total_shipping + $total_wrapping), 2, PHP_ROUND_HALF_DOWN);
			}
		} else {
			$total_paid = $this->context->cart->getOrderTotal(true, Cart::BOTH);
		}

		return $total_paid;
	}

	/*
	 * Exibe mensagem de desconto na opção de pagamento
	*/
	public function messageDiscounts($payment_type)
	{
		$discount_options = $this->checkDiscounts();
		$discount_type = Configuration::get('PAGBANK_DISCOUNT_TYPE');
		$discount_value = (float)Configuration::get('PAGBANK_DISCOUNT_VALUE');
		if (in_array($payment_type, $discount_options) && $discount_type >= 1 && $discount_value >= 1) {
			if($discount_type == 1){
				$discount_msg = ' (- '.$discount_value.'%)';
			}else{
				$discount_msg = ' (- R$ '.$discount_value.')';
			}
		} else {
			$discount_msg = '';
		}

		return $discount_msg;
	}
	
	/*
	 * Processa pagamento com PIX ou PagBank
	*/
	public function processPixPayment($form_data)
	{
		$this->ps_errors = array();
		$this->ps_params = array();
		$this->processReference();
		$this->processFormData($form_data);
		$order_products = $this->processOrderProducts();
		$pix_expiration = Configuration::get('PAGBANK_PIX_TIME_LIMIT');
		$current_hour = date("H", time());
		$total_paid = $this->calculateDiscounts('pix');

		if (((int)$current_hour > 20 || (int)$current_hour < 6) && (int)$total_paid > 999) {
			$pix_expiration = ((24 - (int)$current_hour) + 9) * 60;
		}

		$json_pix = '{
			"reference_id": "' . $this->ps_params['reference'] . '",
			"customer": {
				"name": "' . $this->ps_params['holderName'] . '",
				"email": "' . $this->ps_params['senderEmail'] . '",
				"tax_id": "' . $this->ps_params['senderCPFCNPJ'] . '", 
				"phones": [
					{
						"country": "+55",
						"area": "' . $this->ps_params['senderAreaCode'] . '",
						"number": "' . $this->ps_params['senderPhone'] . '",
						"type": "' . $this->ps_params['senderPhoneType'] . '"
					}
				]
				  
			},
			"items": ' . $order_products . ',
			"qr_codes": [
				{
					"amount": {
						"value": ' . number_format($total_paid, 2, "", "") . '
					},
					"expiration_date": "' . date(DATE_ATOM, strtotime("+{$pix_expiration} minutes")) . '"
				}
			],
			"shipping": {
				"address": {
					"street": "' . $this->ps_params['billingAddressStreet'] . '",
					"number": "' . $this->ps_params['billingAddressNumber'] . '",
					"complement": "' . $this->ps_params['billingAddressComplement'] . '",
					"locality": "' . $this->ps_params['billingAddressDistrict'] . '",
					"city": "' . $this->ps_params['billingAddressCity'] . '",
					"region": "' . $this->ps_params['billingAddressState'] . '",
					"region_code": "' . $this->ps_params['billingAddressStateCode'] . '",
					"country": "BRA",
					"postal_code": "' . $this->ps_params['billingAddressPostalCode'] . '"
				}
			},
			"notification_urls": [
				"' . $this->urls['notification'] . '"
			]
		}';

		$api_response = $this->curl_send('POST', $this->urls['api'] . 'orders', preg_replace('!\?\\n?\\t!', "", $json_pix), 30, $this->context->cart->id);
		if (isset($api_response) && !$api_response['errors']) {
			return $api_response;
		} else {
			$this->ps_errors[] = 'Erro no processamento do PIX.';
			return false;
		}
	}

	/*
	 * Processa pagamento com o super app PagBank
	*/
	public function processWalletPayment($form_data)
	{
		$this->ps_errors = array();
		$this->ps_params = array();
		$this->processReference();
		$this->processFormData($form_data);
		$order_products = $this->processOrderProducts();
		$total_paid = $this->calculateDiscounts('wallet');

		if($this->device === 't' || $this->device === 'm'){
			$link = new Link();
			$qr_deep = '
			"deep_links": [
				{
					"amount": {
						"value": ' . number_format($total_paid, 2, "", "") . '
					},
					"redirect_url": "' . $link->getPageLink('history', true) . '"
				}
			]';
		} else {
			$qr_deep = '
			"qr_codes": [
				{
					"amount": {
						"value": ' . number_format($total_paid, 2, "", "") . '
					},
					"arrangements": ["PAGBANK"]
				}
			]';
		}

		$json_wallet = '{
			"reference_id": "' . $this->ps_params['reference'] . '",
			"customer": {
				"name": "' . $this->ps_params['holderName'] . '",
				"email": "' . $this->ps_params['senderEmail'] . '",
				"tax_id": "' . $this->ps_params['senderCPFCNPJ'] . '", 
				"phones": [
					{
						"country": "+55",
						"area": "' . $this->ps_params['senderAreaCode'] . '",
						"number": "' . $this->ps_params['senderPhone'] . '",
						"type": "' . $this->ps_params['senderPhoneType'] . '"
					}
				]
				  
			},
			"items": ' . $order_products . ',
			' . $qr_deep . ',
			"shipping": {
				"address": {
					"street": "' . $this->ps_params['billingAddressStreet'] . '",
					"number": "' . $this->ps_params['billingAddressNumber'] . '",
					"complement": "' . $this->ps_params['billingAddressComplement'] . '",
					"locality": "' . $this->ps_params['billingAddressDistrict'] . '",
					"city": "' . $this->ps_params['billingAddressCity'] . '",
					"region": "' . $this->ps_params['billingAddressState'] . '",
					"region_code": "' . $this->ps_params['billingAddressStateCode'] . '",
					"country": "BRA",
					"postal_code": "' . $this->ps_params['billingAddressPostalCode'] . '"
				}
			},
			"notification_urls": [
				"' . $this->urls['notification'] . '"
			]
		}';

		$api_response = $this->curl_send('POST', $this->urls['api'] . 'orders', preg_replace('!\?\\n?\\t!', "", $json_wallet), 30, $this->context->cart->id);
		if (isset($api_response) && !$api_response['errors']) {
			return $api_response;
		} else {
			$this->ps_errors[] = 'Erro no processamento via Carteira Digital.';
			return false;
		}
	}

	/* 
	 * Consulta as condições comerciais para a bin do cartão
	 */
	public function callGetInstallments($value, $bin, $id_cart)
	{
		$max_installments = (int)Configuration::get('PAGBANK_MAX_INSTALLMENTS');
		$max_installments_no_interest = (int)Configuration::get('PAGBANK_NO_INTEREST');
		if($max_installments_no_interest == 1) {
			$no_interest = 0;
		} else {
			$no_interest = $max_installments_no_interest;
		}
		$params = array(
			'value' => $value,
			'max_installments' => $max_installments,
			'max_installments_no_interest' => $no_interest,
			'credit_card_bin' => $bin,
			'payment_methods' => 'credit_card',
		);
		
		return $this->curl_send('GET', $this->urls['installments'] . '?' . http_build_query($params, '', '&'), false, 30, $id_cart);
	}

	/*
	* Retorna pedido demo para o Google Pay
	*/
	public function orderDemoGooglePay($form_data)
	{
		$gpay_id = (int)$this->context->cart->id;
		$amount_value = $this->calculateDiscounts('google_pay', 1);
		$formatted_value = number_format($amount_value, 2, "", "");
		$reference = $this->ps_params['reference'];
		$created_at = date(DATE_ATOM, strtotime('now'));

		$json_demo = '{
			"id": "GPAY_' . $gpay_id . '",
			"reference_id": "' . $reference . '",
			"created_at": "' . $created_at . '",
			"charges": [
				{
					"id": "GPAY_' . $gpay_id . ' ",
					"reference_id": " ' . $reference . ' ",
					"status": "PAID",
					"created_at": "' .$created_at . '",
					"amount": {
						"value": ' . $formatted_value . ',
						"currency": "BRL",
						"summary": {
							"total": ' . $formatted_value . ',
							"paid": ' . $formatted_value . ',
							"refunded": 0
						}
					},
					"payment_response": {
						"code": "20000",
						"message": "SUCESSO",
						"reference": "032416400102",
						"raw_data": {
							"authorization_code": "145803",
							"nsu": "032416400102",
							"reason_code": "00"
						}
					},
					"payment_method": {
						"type": "CREDIT_CARD",
						"installments": 1,
						"capture": true,
						"card": {
							"brand": "Visa",
							"last_digits": 1234,
							"wallet": {
								"type": "GOOGLE_PAY"
							}
						}
					},
					"links": [
						{
							"rel": "SELF",
							"href": "https://sandbox.api.pagseguro.com/charges/CHAR_8B3113C2-2FC6-4C8D-9E06-8ED5C35DE8D0",
							"media": "application/json",
							"type": "GET"
						}
					]
				}
			]
		}';

		$api_response = array(
			'errors' => false,
			'response' => json_decode($json_demo),
			'status' => 200
		);

		return $api_response;
	}

	/* 
	 * Processa pagamento com Cartão de crédito no PagBank
	 */
	public function processCardPayment($form_data)
	{

		if ($form_data['payment_type'] === 'google_pay' &&
		(int)Configuration::get('PAGBANK_GOOGLE_ENVIRONMENT') == 0 &&
		(int)Configuration::get('PAGBANK_GOOGLE_ORDER_DEMO') == 1) {
			return $this->orderDemoGooglePay($form_data);
		}

		$this->ps_errors = array();
		$this->ps_params = array();
		$this->processReference();
		$this->processFormData($form_data);
		$order_products = $this->processOrderProducts();

		if ($this->checkTwoOpt($form_data)) {
			$json_part = '';
		} else {
			if ($this->processCardData($form_data) === false) {
				return false;
			}
			$json_part = ',"charges": [
				{
					"reference_id": "' . $this->ps_params['reference'] . '",
					"description": "Pedido realizado na loja ' . Configuration::get('PS_SHOP_NAME') . ', em ' . date("d/m/Y") . ', no valor total de R$ ' . number_format($this->ps_params['amountDesc'], 2, ",", ".") . '",
					"amount": ' . json_encode($this->ps_params['amount']) . ',
					"payment_method": {
						"type": "CREDIT_CARD",
						"installments": ' . (int)$this->ps_params['cardInstallments'] . ',
						"capture": ' . $this->ps_params['capture'] . ',
						"card": ' . json_encode($this->ps_params['paymentMethodCard']) . ',
						"holder": {
							"name": "' . $this->ps_params['holderName'] . '",
							"tax_id": "' . $this->ps_params['senderCPFCNPJ'] . '"
						}
					}
				}
			]';
		}

		$json_credit_card = '{
			"reference_id": "' . $this->ps_params['reference'] . '",
			"customer": {
				"name": "' . $this->ps_params['senderName'] . '",
				"email": "' . $this->ps_params['senderEmail'] . '",
				"tax_id": "' . $this->ps_params['senderCPFCNPJ'] . '", 
				"phones": [
					{
						"country": "+55",
						"area": "' . $this->ps_params['senderAreaCode'] . '",
						"number": "' . $this->ps_params['senderPhone'] . '",
						"type": "' . $this->ps_params['senderPhoneType'] . '"
					}
				]
			},
			"items": ' . $order_products . ',
			"shipping": {
				"address": {
					"street": "' . $this->ps_params['billingAddressStreet'] . '",
					"number": "' . $this->ps_params['billingAddressNumber'] . '",
					"complement": "' . $this->ps_params['billingAddressComplement'] . '",
					"locality": "' . $this->ps_params['billingAddressDistrict'] . '",
					"city": "' . $this->ps_params['billingAddressCity'] . '",
					"region": "' . $this->ps_params['billingAddressState'] . '",
					"region_code": "' . $this->ps_params['billingAddressStateCode'] . '",
					"country": "BRA",
					"postal_code": "' . $this->ps_params['billingAddressPostalCode'] . '"
				}
			},
			"notification_urls": [
				"' . $this->urls['notification'] . '"
			]
			'. $json_part .'
		}';

		$api_response = $this->curl_send('POST', $this->urls['api'] . 'orders', preg_replace("!\?\\n?\\t!", "", $json_credit_card), 30, $this->context->cart->id);
		if (isset($api_response) && !$api_response['errors']) {
			$this->saveCardTokenized($api_response, (int)$form_data['save_customer_card']);
			return $api_response;
		} else {
			$this->ps_errors[] = 'Erro no processamento do cartão.';
			return false;
		}
	}

	/* 
	 * Processa pagamento com Boleto no PagBank
	 */
	public function processBankSlipPayment($form_data)
	{
		$this->ps_errors = array();
		$this->ps_params = array();
		$this->processReference();
		$this->processFormData($form_data);
		$order_products = $this->processOrderProducts();

		if ((int)Configuration::get('PAGBANK_BANKSLIP_DATE_LIMIT') <= 2) {
			$aditional_time = '+2 days';
		} else {
			$aditional_time = '+' . (int)Configuration::get('PAGBANK_BANKSLIP_DATE_LIMIT') . ' days';
		}

		$total_paid = $this->calculateDiscounts('bankslip');

		$json_bankslip = '{
			"reference_id": "' . $this->ps_params['reference'] . '",
			"customer": {
				"name": "' . $this->ps_params['senderName'] . '",
				"email": "' . $this->ps_params['senderEmail'] . '",
				"tax_id": "' . $this->ps_params['senderCPFCNPJ'] . '", 
				"phones": [
					{
						"country": "+55",
						"area": "' . $this->ps_params['senderAreaCode'] . '",
						"number": "' . $this->ps_params['senderPhone'] . '",
						"type": "' . $this->ps_params['senderPhoneType'] . '"
					}
				]
				  
			},
			"items": ' . $order_products . ',
			"shipping": {
				"address": {
					"street": "' . $this->ps_params['billingAddressStreet'] . '",
					"number": "' . $this->ps_params['billingAddressNumber'] . '",
					"complement": "' . $this->ps_params['billingAddressComplement'] . '",
					"locality": "' . $this->ps_params['billingAddressDistrict'] . '",
					"city": "' . $this->ps_params['billingAddressCity'] . '",
					"region": "' . $this->ps_params['billingAddressState'] . '",
					"region_code": "' . $this->ps_params['billingAddressStateCode'] . '",
					"country": "BRA",
					"postal_code": "' . $this->ps_params['billingAddressPostalCode'] . '"
				}
			},
			"notification_urls": [
				"' . $this->urls['notification'] . '"
			],
			"charges": [
				{
					"reference_id": "' . $this->ps_params['reference'] . '",
					"description": "' . Configuration::get('PAGBANK_BANKSLIP_TEXT') . '",
					"amount": {
						"value": ' . number_format($total_paid, 2, "", "") . ',
						"currency": "BRL"
					},
					"payment_method": {
						"type": "BOLETO",
						"boleto": {
							"due_date": "' . date("Y-m-d", strtotime($aditional_time)) . '",
							"instruction_lines": {
								"line_1": "' . Configuration::get('PAGBANK_BANKSLIP_TEXT') . '",
								"line_2": "Processado pelo PagBank em ' . date('d/m/Y') . '"
							},
							"holder": {
								"name": "' . $this->ps_params['holderName'] . '",
								"tax_id": "' . $this->ps_params['senderCPFCNPJ'] . '",
								"email": "' . $this->ps_params['senderEmail'] . '",
									"address": {
										"street": "' . $this->ps_params['billingAddressStreet'] . '",
										"number": "' . $this->ps_params['billingAddressNumber'] . '",
										"complement": "' . $this->ps_params['billingAddressComplement'] . '",
										"locality": "' . $this->ps_params['billingAddressDistrict'] . '",
										"city": "' . $this->ps_params['billingAddressCity'] . '",
										"region": "' . $this->ps_params['billingAddressState'] . '",
										"region_code": "' . $this->ps_params['billingAddressStateCode'] . '",
										"country": "BRA",
										"postal_code": "' . $this->ps_params['billingAddressPostalCode'] . '"
									}
							}
						}
					}
				}
			]
		}';

		$api_response = $this->curl_send('POST', $this->urls['api'] . 'orders', preg_replace('!\?\\n?\\t!', "", $json_bankslip), 30, $this->context->cart->id);
		if (isset($api_response) && !$api_response['errors']) {
			return $api_response;
		} else {
			$this->ps_errors[] = 'Erro no processamento do boleto.';
			return false;
		}
	}

	/* 
	 * Retorna dados da transação no PagBank
	 * $code = Código da transação
	 */
	public function getTransaction($code, $id_cart = false)
	{
		if (isset($id_cart)) {
			if(strpos($code, 'GPAY') !== false){
				return;
			}

			$info = $this->getOrderData($id_cart, 'id_cart');
			if (!empty($info) && $info['environment'] == 1 ||
			!empty($info) && $info['environment'] === '' ||
			!empty($info) && $info['environment'] === 'NULL') {
				$this->urls['api'] = 'https://api.pagseguro.com/';
			} else {
				$this->urls['api'] = 'https://sandbox.api.pagseguro.com/';
			}
		}

		$api_response = $this->curl_send('GET', $this->urls['api'] . 'orders/' . $code, false, 30, $id_cart);
		if (isset($api_response) && !$api_response['errors']) {
			return $api_response['response'];
		} else {
			$this->ps_errors[] = 'Erro ao consultar Transação.';
			return false;
		}
	}

	/* 
	 * Devolve o valor da transação ao cliente
	 * $code = Código da transação
	 * $value = valor devolvido, total ou parcial
	 */
	public function refundTransaction($transaction_charge, $value, $order = false, $transaction_code = false)
	{
		$json_refund = '{
			"amount": {
				"value": ' . $value . '
			}
		}';
		if ($order === false) {
			$id_cart = $this->context->cart->id;
		} else {
			$id_cart = $order->id_cart;
		}
		$api_response = $this->curl_send('POST', $this->urls['api'] . 'charges/' . $transaction_charge . '/cancel', $json_refund, 20, $id_cart);
		if (isset($api_response) && !$api_response['errors']) {
			if ($order) {
				$current_status = $this->checkStatusApi($transaction_code, $id_cart);
				$this->updateOrderStatus($current_status, $order->id, date("Y-m-d H:i:s"));
			}
		} else {
			$this->ps_errors[] = 'Erro ao estornar Transação.';
			return false;
		}
	}

	/* 
	 * Captura o pagamento no cartão do cliente
	 * $code = Código da transação
	 * $value = total ou parcial
	 */
	public function captureTransaction($transaction_charge, $value, $order = false, $transaction_code = false)
	{
		$json_capture = '{
			"amount": {
				"value": ' . $value . '
			}
		}';
		if ($order === false) {
			$id_cart = $this->context->cart->id;
		} else {
			$id_cart = $order->id_cart;
		}
		$api_response = $this->curl_send('POST', $this->urls['api'] . 'charges/' . $transaction_charge . '/capture', $json_capture, 20, $id_cart);
		if (isset($api_response) && !$api_response['errors']) {
			if ($order) {
				$current_status = $this->checkStatusApi($transaction_code, $id_cart);
				$this->updateOrderStatus($current_status, $order->id, date("Y-m-d H:i:s"));
			}
			return true;
		} else {
			$this->ps_errors[] = 'Erro capturar a Transação.';
			return false;
		}
	}

	/*
	* Verifica Status da Transação no PankBank
	*/
	public function checkStatusApi($transaction_code, $id_cart)
	{
		$get_transaction = $this->getTransaction($transaction_code, $id_cart);

		if (isset($get_transaction->charges) && is_array($get_transaction->charges) && count($get_transaction->charges) == 2) {
			$validate_charges = $this->validateTwoCharges($get_transaction->charges);
			return $validate_charges['current_status'];
		} else {
			if (isset($get_transaction->charges) && !in_array(substr($get_transaction->charges[0]->reference_id, -2), ['_1', '_2'])) {
				return (string)$get_transaction->charges[0]->status;
			} else {
				return;
			}
		}
	}

	/* 
	 * Atualiza Status do pedido na loja
	 */
	public function updateOrderStatus($status_code, $id_order, $date_update = null)
	{
		$order = new Order($id_order);
		$current_order_status = (int)$order->getCurrentState();
		$parse_status_api = (int)$this->correspondStatus($status_code);
		$info = $this->getOrderData($order->id_cart, 'id_cart');

		if ($current_order_status == $parse_status_api) {
			return;
		} else {
			$status_history = $order->getHistory($this->context->language->id);
			$s_history = array();
			foreach ($status_history as $status) {
				$s_history[] = $status['id_order_state'];
			}
			if (isset($parse_status_api) && $parse_status_api != false && $current_order_status != $parse_status_api) {
				if (in_array($parse_status_api, $s_history)) {
					return;
				} else {
					$history = new OrderHistory();
					$history->id_order = (int)$id_order;
					$history->changeIdOrderState($parse_status_api, (int)$id_order);
					$template_vars = array(
						'{transaction_code}' => $info['transaction_code'],
						'{status}' => $status_code,
						'{status_description}' => $this->parseStatus($status_code)
					);
					if (!$history->addWithemail(true, $template_vars)) {
						$this->saveLog('error', 'Atualiza Status', $order->id_cart, 'Status PagBank: ' . $parse_status_api . ' / Status Loja: ' . (int)$current_order_status, 'Status do pedido não atualizado na loja.');
					}
					$history->save();
				}
				$data = array(
					'transaction_code' => $info['transaction_code'],
					'status' => $status_code,
					'status_description' => $this->parseStatus($status_code),
					'date_upd' => isset($date_update) && $date_update ? $date_update : ''
				);

				$this->updatePagBankData($data);

				return true;
			}
		}
	}

	/* 
	 * Processa o reCaptcha v3
	 */
	public function processRecaptcha($token)
	{
		$site_key = trim(Configuration::get('PAGBANK_RECAPTCHA_SITE_KEY'));
		$api_key = trim(Configuration::get('PAGBANK_RECAPTCHA_API_KEY'));
		$project_url = trim(Configuration::get('PAGBANK_RECAPTCHA_URL'));
		$user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
		$user_ip = $this->getUserIp();
		$data = '{
			"event": {
				"token": "' . $token . '",
				"siteKey": "' . $site_key . '",
				"userAgent": "' . $user_agent . '",
				"userIpAddress": "' . $user_ip . '",
				"expectedAction": "submit"
			}
		}';
		$endpoint = str_replace('API_KEY', $api_key, $project_url);
		$api_response = $this->curl_send('POST', $endpoint, preg_replace("!\?\\n?\\t!", "", $data), 30, $this->context->cart->id, true);
		if (isset($api_response) && !$api_response['errors']) {
			return $this->validateRecaptcha($api_response['response']->riskAnalysis->score);
		} else {
			$this->ps_errors[] = 'Erro no processamento do Recaptcha.';
			return false;
		}
	}

	/* 
	 * Classifica o score do reCaptcha v3
	 */
	public function validateRecaptcha($score)
	{
		$criteria = Configuration::get('PAGBANK_RACAPTCHA_CRITERIA');
		switch (strtolower((string)$criteria)) {
			case 'low':
				$min = 0.3;
				break;
			case 'high':
				$min = 0.7;
				break;
			case 'medium':
			default:
				$min = 0.5;
				break;
		}

		if((float)$score >= $min) {
			return true;
		} else {
			return false;
		}
	}

	/* 
	 * Gera referência única pra tentativa de pagamento
	 */
	private function processReference()
	{

		$this->ps_params['reference'] = $this->context->cart->id . '.' . $this->credential_type . '.' . $this->sortRefNumber();

	}

	/*
	 * Processa produtos do carrinho para envio ao PagBank
	*/
	private function processOrderProducts()
	{
		$order_products = $this->context->cart->getProducts();

		$products_array = array();
		foreach ($order_products as $product) {
			if ($product['price_wt'] <= 0) {
				continue;
			}
			$product_name = str_replace("'", "", $product['name']);
			$products_array[] = array(
				"reference_id" => $product['id_product'],
				"name" => $this->replaceSpecialChars(substr($product_name, 0, 64)),
				"quantity" => $product['cart_quantity'],
				"unit_amount" => number_format($product['price_wt'], 2, "", ""),
				"dimensions" => array(
					"length" => $product['depth'],
					"width" => $product['width'],
					"height" => $product['height']
				),
				"weight" => $product['weight']
			);
		}
		if (empty($products_array) || count($products_array) < 1) {
			$this->ps_errors[] = 'Erro ao Processar Produtos.';
			return false;
		} else {
			return json_encode($products_array);
		}
	}

	/*
	 * Processa dados do formulário de pagamento para envio ao PagBank
	*/
	private function processFormData($form_data)
	{
		//Dados do Cliente
		$cpf_cnpj = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $form_data['cpf_cnpj']));
		$telephone = $this->formatPhoneNumber($form_data['telephone']);
		$email = $this->context->customer->email;
		$name = trim($this->context->customer->firstname) . ' ' . trim($this->context->customer->lastname);
		$name = preg_replace('/\s(?=\s)/', '', $name);
		if (strlen($name) > 50) {
			$name = substr($name, 0, 50);
		}
		if (isset($form_data['card_name']) && strlen($form_data['card_name']) > 3) {
			$holder_name = trim($form_data['card_name']);
		} elseif (isset($form_data['bankslip_name']) && strlen($form_data['bankslip_name']) > 3) {
			$holder_name = trim($form_data['bankslip_name']);
		} elseif (isset($form_data['pix_name']) && strlen($form_data['pix_name']) > 3) {
			$holder_name = trim($form_data['pix_name']);
		} elseif (isset($form_data['wallet_name']) && strlen($form_data['wallet_name']) > 3) {
			$holder_name = trim($form_data['wallet_name']);
		} elseif (isset($form_data['google_name']) && strlen($form_data['google_name']) > 3) {
			$holder_name = trim($form_data['google_name']);
		}
		$holder_name = preg_replace('/\s(?=\s)/', '', $holder_name);
		if (strlen($holder_name) > 50) {
			$holder_name = substr($holder_name, 0, 50);
		}

		$this->ps_params['senderEmail'] = $email;
		$this->ps_params['senderName'] = $name;
		$this->ps_params['holderName'] = $holder_name;
		$this->ps_params['senderCPFCNPJ'] = $cpf_cnpj;
		$this->ps_params['senderAreaCode'] = $telephone['area_code'];
		$this->ps_params['senderPhone'] = $telephone['telephone_number'];
		$this->ps_params['senderPhoneType'] = (int)substr($telephone['telephone_number'], 0, 1) == 9 ? 'MOBILE' : 'BUSINESS';
		
		if ($this->checkTwoOpt($form_data)) {
			$holder_name_two = trim($form_data['card_name_two']);
			$holder_name_two = preg_replace('/\s(?=\s)/', '', $holder_name_two);
			if (strlen($holder_name_two) > 50) {
				$holder_name_two = substr($holder_name_two, 0, 50);
			}
			$this->ps_params['holderNameTwo'] = $holder_name_two;
			$cpf_cnpj_two = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $form_data['cpf_cnpj_two']));
			$this->ps_params['senderCPFCNPJTwo'] = $cpf_cnpj_two;
		}

		//Endereço do cliente
		$address = new Address((int)$this->context->cart->id_address_delivery);
		$city = $address->city;
		if (strlen($city) > 60) {
			$city = substr($city, 0, 60);
		}
		$postcode = preg_replace('/[^0-9]/', '', $address->postcode);
		$state = new State((int)$address->id_state);
		$uf = $state->iso_code;
		$uf_name = $state->name;
		$frete = $this->context->cart->getOrderTotal(true, Cart::ONLY_SHIPPING);
		if ($frete > 0) {
			$this->ps_params['shippingType'] = '3';
			$this->ps_params['shippingCost'] = number_format($frete, 2, '.', '');
		}
		$this->ps_params['shippingAddressCountry'] = 'BRA';
		$this->ps_params['shippingAddressState'] = $uf_name;
		$this->ps_params['shippingAddressStateCode'] = $uf;
		$this->ps_params['shippingAddressCity'] = $city;
		$this->ps_params['shippingAddressPostalCode'] = $postcode;
		$this->ps_params['shippingAddressDistrict'] = $address->address2;
		$this->ps_params['shippingAddressStreet'] = $address->address1;
		$this->ps_params['shippingAddressNumber'] = isset($address->{$this->number_field}) && strlen($address->{$this->number_field}) > 0 ? substr($address->{$this->number_field}, 0, 20) : '1';
		$this->ps_params['shippingAddressComplement'] = isset($this->compl_field) && $address->{$this->compl_field} != '' ? substr($address->{$this->compl_field}, 0, 40) : 'N/A';

		if ((empty($this->ps_params['shippingAddressState']) && empty($this->ps_params['shippingAddressCity'])) || 
			empty($this->ps_params['shippingAddressPostalCode']) || empty($this->ps_params['shippingAddressDistrict']) || 
			empty($this->ps_params['shippingAddressStreet']) || empty($this->ps_params['shippingAddressNumber'])) {
			$this->ps_errors[] = 'Erro ao Processar Endereço de Entrega.';
		}

		//Endereço de Cobrança
		$address_invoice = new Address((int)$this->context->cart->id_address_invoice);
		$city = $address_invoice->city;
		if (strlen($city) > 60) {
			$city = substr($city, 0, 60);
		}
		$postcode = preg_replace('/[^0-9]/', '', $address_invoice->postcode);
		$state = new State((int)$address_invoice->id_state);
		$uf_name = $state->name;
		$uf_sigla = $state->iso_code;
		$this->ps_params['billingAddressPostalCode'] = isset($form_data['invoice_postcode']) && $form_data['invoice_postcode'] != '' ? preg_replace('/[^0-9]/', '', $form_data['invoice_postcode']) : $postcode;
		$this->ps_params['billingAddressStreet'] = isset($form_data['invoice_address']) && $form_data['invoice_address'] != '' ? $form_data['invoice_address'] : $address_invoice->address1;
		$this->ps_params['billingAddressNumber'] = isset($form_data['invoice_number']) && $form_data['invoice_number'] != '' ? substr($form_data['invoice_number'], 0, 20) : substr($address_invoice->{$this->number_field}, 0, 20);
		$this->ps_params['billingAddressComplement'] = isset($form_data['invoice_complement']) && $form_data['invoice_complement'] != '' ? substr($form_data['invoice_complement'], 0, 40) : 'N/A';
		$this->ps_params['billingAddressDistrict'] = isset($form_data['invoice_district']) && $form_data['invoice_district'] != '' ? $form_data['invoice_district'] : $address_invoice->address2;
		$this->ps_params['billingAddressCity'] = isset($form_data['invoice_city']) && $form_data['invoice_city'] != '' ? $form_data['invoice_city'] : $city;
		$this->ps_params['billingAddressState'] = isset($form_data['invoice_state']) && $form_data['invoice_state'] != '' ? $this->getStateByIsoCode($form_data['invoice_state'], 'name') : $uf_name;
		$this->ps_params['billingAddressStateCode'] = isset($form_data['invoice_state']) && $form_data['invoice_state'] != '' ? $form_data['invoice_state'] : $uf_sigla;
		$this->ps_params['billingAddressCountry'] = 'BRA';
		if (
			(empty($this->ps_params['billingAddressState']) && empty($this->ps_params['billingAddressCity'])) ||
			empty($this->ps_params['billingAddressPostalCode']) ||
			empty($this->ps_params['billingAddressDistrict']) ||
			empty($this->ps_params['billingAddressStreet']) ||
			empty($this->ps_params['billingAddressNumber'])
		) {
			$this->ps_errors[] = 'Erro ao Processar Endereço de Cobrança.';
		}
	}

	/* 
	 * Processa dados do cartão de crédito para ser enviado ao PagBank
	 */
	public function processCardData($form_data)
	{

		if ($this->checkFormInfo($form_data) === false) {
			return false;
		}

		if((int)Configuration::get('PAGBANK_CAPTURE_METHOD') == 1){
			$this->ps_params['capture'] = "true";
		} else {
			$this->ps_params['capture'] = "false";
		}

		// Cartão
		if ($form_data['payment_type'] === 'credit_card') {

			if (isset($form_data['save_customer_card']) && (int)$form_data['save_customer_card'] > 0) {
				$this->ps_params['storeCard'] = true;
			} else {
				$this->ps_params['storeCard'] = false;
			}

			if (isset($form_data['saved_card']) && (int)$form_data['saved_card'] > 0 
				&& isset($form_data['card_token_id']) && (int)$form_data['card_token_id'] > 0) {
				$check_saved = $this->getCustomerToken((int)$this->context->cart->id_customer, (int)$form_data['card_token_id']);
				$bin = $check_saved[0]['card_first_digits'];
				$card_brand = $check_saved[0]['card_brand'];
				$card_hash = $this->getCardToken($form_data['card_token_id']);
				$this->ps_params['paymentMethodCard'] = array(
					"id" => $card_hash
				);
			} else {
				$bin = $form_data['card_bin'];
				$card_brand = $form_data['card_brand'];
				$encrypted_card = $form_data['encrypted_card'];
				$this->ps_params['paymentMethodCard'] = array(
					"encrypted" => $encrypted_card,
					"store" => $this->ps_params['storeCard']
				);
			}

			$this->ps_params['cardInstallments'] = $form_data['card_installments'];

			if ($this->checkTwoOpt($form_data)) {
				$this->ps_params['cardInstallmentsTwo'] = $form_data['card_installments_two'];
				$bin_two = $form_data['card_bin_two'];
				$card_brand_two = $form_data['card_brand_two'];
				$this->ps_params['paymentMethodCardTwo'] = $form_data['encrypted_card_two'];
				$this->ps_params['cardOneInput'] = str_replace([',', '.'], '', $form_data['card_one_input']);
				$this->ps_params['cardTwoInput'] = str_replace([',', '.'], '', $form_data['card_two_input']);
			}

		// Google Pay
		} else {

			$this->ps_params['cardInstallments'] = $form_data['google_installments'];
			$bin = $form_data['google_card_bin'];
			$card_brand = strtolower($form_data['google_card_brand']);
			$google_signature = preg_replace('~^"?(.*?)"?$~', '$1', $form_data['google_signature']);

			if (_PS_VERSION_ >= '1.7.0') {
				$google_param = stripslashes($google_signature);
			} else {
				$google_param = $google_signature;
			}

			$this->ps_params['paymentMethodCard'] = [
				"wallet" => [
					"type" => "GOOGLE_PAY",
					"key" => $google_param
				]
			];

		}

		$total_cart = number_format($this->context->cart->getOrderTotal(true, Cart::BOTH), 2, "", "");
		$minimum_inst = (int)Configuration::get('PAGBANK_MINIMUM_INSTALLMENTS');
		$card_value_pagbank = (int)$form_data['card_value_pagbank'];

		// 1 ou primeiro cartão
		if ((int)$this->ps_params['cardInstallments'] == 1) {
			if($form_data['payment_type'] === 'credit_card') {
				if ($this->checkTwoOpt($form_data)) {
					$amount_value = $this->ps_params['cardOneInput'];
				} else {
					$amount_value = number_format($this->calculateDiscounts('credit_card', 1), 2, "", "");
				}
			} else {
				$amount_value = number_format($this->calculateDiscounts('google_pay', 1), 2, "", "");
			}
			$this->ps_params['amountDesc'] = $amount_value/100;
			$this->ps_params['amount'] = [
				"value" => $amount_value,
				"currency" => "BRL"
			];
			if ($this->checkTwoOpt($form_data)) {
				$check_value = $amount_value;
			} else {
				$check_value = $total_cart;
			}
		} else {
			if ($this->checkTwoOpt($form_data)) {
				$installments = $this->callGetInstallments($this->ps_params['cardOneInput'], $bin, (int)$this->context->cart->id);
			} else {
				$installments = $this->callGetInstallments($total_cart, $bin, (int)$this->context->cart->id);
			}
			$inst_array = json_decode(json_encode($installments['response']));
			$plans = $inst_array->payment_methods->credit_card->{$card_brand}->installment_plans;
			foreach($plans as $p){
				if($p->installments == (int)$this->ps_params['cardInstallments']) {
					$selected_install = $p;
				}
			}
			$amount_value = $selected_install->amount->value;
			$this->ps_params['amountDesc'] = $amount_value/100;
			if((int)$this->ps_params['cardInstallments'] <= (int)Configuration::get('PAGBANK_NO_INTEREST')) {
				$this->ps_params['amount'] = [
					"value" => $amount_value,
					"currency" => "BRL"
				];
			} else {
				$this->ps_params['amount'] = $selected_install->amount;
			}
			$check_value = $plans[0]->installment_value;
		}

		// Só segundo cartão
		if ($this->checkTwoOpt($form_data)) {
			if((int)$this->ps_params['cardInstallmentsTwo'] == 1) {
				$this->ps_params['amountDescTwo'] = $this->ps_params['cardTwoInput']/100;
				$this->ps_params['amountTwo'] = [
					"value" => $this->ps_params['cardTwoInput'],
					"currency" => "BRL"
				];
				$check_value_two = $this->ps_params['cardTwoInput'];
			} else {
				if ((int)Configuration::get('PAGBANK_TWO_CREDIT_CARD_INST') == 1) {
					$installments_two = $this->callGetInstallments($this->ps_params['cardTwoInput'], $bin_two, (int)$this->context->cart->id);
					$inst_array_two = json_decode(json_encode($installments_two['response']));
					$plans_two = $inst_array_two->payment_methods->credit_card->{$card_brand_two}->installment_plans;
					foreach($plans_two as $ptwo){
						if($ptwo->installments == (int)$this->ps_params['cardInstallmentsTwo']) {
							$selected_install_two = $ptwo;
						}
					}
					$amount_value_two = $selected_install_two->amount->value;
					$this->ps_params['amountDescTwo'] = $amount_value_two/100;
					if((int)$this->ps_params['cardInstallmentsTwo'] <= (int)Configuration::get('PAGBANK_NO_INTEREST')) {
						$this->ps_params['amountTwo'] = [
							"value" => $amount_value_two,
							"currency" => "BRL"
						];
					} else {
						$this->ps_params['amountTwo'] = $selected_install_two->amount;
					}
					$check_value_two = $plans_two[0]->installment_value;
				} else {
					return false;
				}
			}
		}

		// Validação dos valores
		if ($this->checkTwoOpt($form_data)) {
			$card_input_values = $this->ps_params['cardOneInput'] + $this->ps_params['cardTwoInput'];
			$card_api_values = $check_value + $check_value_two;
			if ($check_value != $this->ps_params['cardOneInput'] || $check_value_two != $this->ps_params['cardTwoInput'] ||
				$card_input_values != $total_cart || $card_api_values != $card_value_pagbank ||
				$this->ps_params['cardTwoInput'] < $minimum_inst) {
				return false;
			}
		} else {
			if ($check_value != $card_value_pagbank) {
				return false;
			}
		}

	}

	/*
	* Valida dados do cartão
	*/
	public function checkFormInfo($form_data)
	{
		if ($form_data['payment_type'] === 'credit_card') {
			if ((int)Configuration::get('PAGBANK_TWO_CREDIT_CARD') == 1 && 
				(isset($form_data['pay_two_card_check']) && 
				(int)$form_data['pay_two_card_check'] > 0)) {
				if ((isset($form_data['card_name']) && $form_data['card_name'])
					&& (isset($form_data['card_name_two']) && $form_data['card_name_two'])
					&& (isset($form_data['cpf_cnpj']) && $form_data['cpf_cnpj'])
					&& (isset($form_data['cpf_cnpj_two']) && $form_data['cpf_cnpj_two'])
					&& (isset($form_data['encrypted_card']) && $form_data['encrypted_card']) 
						|| (isset($form_data['card_token_id']) && $form_data['card_token_id'])
					&& (isset($form_data['encrypted_card_two']) && $form_data['encrypted_card_two'])) {
					return true;
				} else {
					return false;
				}
			} else {
				if ((isset($form_data['card_name']) && $form_data['card_name'])
					&& (isset($form_data['cpf_cnpj']) && $form_data['cpf_cnpj'])
					&& (isset($form_data['encrypted_card']) && $form_data['encrypted_card']) 
						|| (isset($form_data['card_token_id']) && $form_data['card_token_id'])) {
					return true;
				} else {
					return false;
				}
			}
		} else {
				if ((isset($form_data['google_name']) && $form_data['google_name'])
					&& (isset($form_data['cpf_cnpj']) && $form_data['cpf_cnpj'])
					&& (isset($form_data['google_signature']) && $form_data['google_signature'])) {
					return true;
				} else {
					return false;
				}
		}
	}

	/*
	* Valida se o pagamento com 2 cartões está disponível
	*/
	public function checkTwoOpt($form_data)
	{
		if ($form_data['payment_type'] === 'credit_card') {
			if ((int)Configuration::get('PAGBANK_TWO_CREDIT_CARD') == 1 && 
				(isset($form_data['pay_two_card_check']) && 
				(int)$form_data['pay_two_card_check'] > 0)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/*
	* Salva o cartão Tokenizado
	*/
	public function saveCardTokenized($api_response, $saved_card)
	{
		if (isset($api_response['response']->charges) && isset($api_response['response']->charges[0]->payment_method->card->id)
			&& isset($saved_card) && (int)$saved_card > 0) {
			$charge = $api_response['response']->charges[0];
			if (in_array($charge->status, array('AVAILABLE', 'AUTHORIZED', 'PAID', 'IN_ANALYSIS'))) {
				$info = array(
					'id_customer' => (int)$this->context->cart->id_customer,
					'card_name' => $charge->payment_method->card->holder->name,
					'card_brand' => $charge->payment_method->card->brand,
					'card_first_digits' => $charge->payment_method->card->first_digits,
					'card_last_digits' => $charge->payment_method->card->last_digits,
					'card_month' => $charge->payment_method->card->exp_month,
					'card_year' => $charge->payment_method->card->exp_year,
					'card_token' => $charge->payment_method->card->id
				);
				$this->insertCustomerToken($info);
			}
		}
	}

	/*
	* Processa duas charges no pagamento
	*/
	public function processTwoCharges($transaction_code, $form_data)
	{
		$this->ps_errors = array();
		$this->ps_params = array();
		$this->processReference();
		$this->processFormData($form_data);

		if ($this->processCardData($form_data) === false) {
			return false;
		}

		$json_charges_one = '{
			"charges": [
				{
					"reference_id": "' . $this->ps_params['reference'] . '_1",
					"description": "Pedido realizado na loja ' . Configuration::get('PS_SHOP_NAME') . ', em ' . date("d/m/Y") . ', no valor total de R$ ' . number_format($this->ps_params['amountDesc'], 2, ".", ",") . '",
					"amount": ' . json_encode($this->ps_params['amount']) . ',
					"notification_urls": "' . $this->urls['notification'] . '",
					"payment_method": {
						"type": "CREDIT_CARD",
						"installments": ' . (int)$this->ps_params['cardInstallments'] . ',
						"capture": false,
						"card": ' . json_encode($this->ps_params['paymentMethodCard']) . ',
						"holder": {
							"name": "' . $this->ps_params['holderName'] . '",
							"tax_id": "' . $this->ps_params['senderCPFCNPJ'] . '"
						}
					}
				}
			]
		}';

		$json_charges_two = '{
			"charges": [
				{
					"reference_id": "' . $this->ps_params['reference'] . '_2",
					"description": "Pedido realizado na loja ' . Configuration::get('PS_SHOP_NAME') . ', em ' . date("d/m/Y") . ', no valor total de R$ ' . number_format($this->ps_params['amountDescTwo'], 2, ".", ",") . '",
					"amount": ' . json_encode($this->ps_params['amountTwo']) . ',
					"notification_urls": "' . $this->urls['notification'] . '",
					"payment_method": {
						"type": "CREDIT_CARD",
						"installments": ' . (int)$this->ps_params['cardInstallmentsTwo'] . ',
						"capture": false,
						"card": {
							"encrypted": "' . $this->ps_params['paymentMethodCardTwo'] . '",
							"store": false
						},
						"holder": {
							"name": "' . $this->ps_params['holderNameTwo'] . '",
							"tax_id": "' . $this->ps_params['senderCPFCNPJTwo'] . '"
						}
					}
				}
			]
		}';

		$api_response_one = $this->curl_send('POST', $this->urls['api'] . 'orders/' . $transaction_code . '/pay', preg_replace("!\?\\n?\\t!", "", $json_charges_one), 30, $this->context->cart->id);
		$api_response_two = $this->curl_send('POST', $this->urls['api'] . 'orders/' . $transaction_code . '/pay', preg_replace("!\?\\n?\\t!", "", $json_charges_two), 30, $this->context->cart->id);
		if (!$api_response_one['errors'] && !$api_response_two['errors']) {
			$this->saveCardTokenized($api_response_one, (int)$form_data['save_customer_card']);
			return ["response_one" => $api_response_one, "response_two" => $api_response_two];
		} else {
			$this->ps_errors[] = 'Erro no processamento das Charges.';
			return false;
		}
	}

	/*
	* Valida o retorno do pagamento
	*/
	public function validateTwoCharges($transaction_charges)
	{
		$declined = 0;
		$in_analysis = false;
		$authorized = false;
		$paid = 0;
		$last_digits = '';
		$message = '';
		$code = '';
		foreach ($transaction_charges as $charge) {
			if ($charge->status === 'DECLINED') {
				$declined++;
				$last_digits = $charge->payment_method->card->last_digits;
				$message = $charge->payment_response->message;
				$code = $charge->payment_response->code;
			} elseif ($charge->status === 'IN_ANALYSIS') {
				$in_analysis = true;
			} elseif ($charge->status === 'AUTHORIZED') {
				$authorized = true;
			} elseif ($charge->status === 'PAID') {
				$paid++;
			}
		}
		if ($paid == 2) {
			$current_status = 'PAID';
		} else {
			if ($in_analysis) {
				$current_status = 'IN_ANALYSIS';
			}
			if ($declined > 0) {
				foreach ($transaction_charges as $charge_d) {
					if ($charge_d->status != 'DECLINED') {
						$transaction_id_charge = $charge_d->id;
						$value = $charge_d->amount->value;
						$this->refundTransaction($transaction_id_charge, $value, false);
					}
				}
				$current_status = 'DECLINED';
			}
			if ($authorized && !$in_analysis && $declined == 0) {
				if((int)Configuration::get('PAGBANK_CAPTURE_METHOD') == 1){
					foreach ($transaction_charges as $charge_a) {
						if ($charge_a->status === 'AUTHORIZED') {
							$transaction_id_charge = $charge_a->id;
							$value = $charge_a->amount->value;
							$this->captureTransaction($transaction_id_charge, $value, false);
						}
					}
					$current_status = 'PAID';
				} else {
					$current_status = 'AUTHORIZED';
				}
			}
		}
		return ["current_status" => $current_status, 
				"last_digits"  => $last_digits, 
				"declined" => $declined, 
				"message" => $message, 
				"code" => $code];
	}

	/* 
	 * Padroniza e valida os dados do telefone do cliente para envio ao PagBank
	 */
	public function formatPhoneNumber($phone)
	{
		$cod_area = '';
		$tel = '';
		$telephone = preg_replace('/[^0-9]/', '', $phone);
		$len = strlen($telephone);
		$cod_area = substr($telephone, 0, 2);
		if ($len == 10) {
			$tel = substr($telephone, 2, 8);
		} else {
			$tel = substr($telephone, 2, 9);
		}
		return array(
			'phone' => $phone,
			'area_code' => $cod_area,
			'telephone_number' => $tel
		);
	}

	/* 
	 * Retorna texto do Status do PagBank a partir do código
	 */
	public function parseStatus($status_code)
	{
		$status = array(
			'AUTHORIZED' => 'Pagamento autorizado',
			'AVAILABLE' => 'Pagamento recebido',
			'PAID' => 'Pagamento aceito',
			'IN_ANALYSIS' => 'Pagamento em análise',
			'WAITING' => 'Aguardando pagamento',
			'CANCELED' => 'Pagamento cancelado',
			'DECLINED' => 'Pagamento não autorizado',
			'DISPUTE' => 'Em disputa',
			'REFUNDED' => 'Estono total ou parcial realizado',
		);
		return (array_key_exists($status_code, $status) ? $status[$status_code] : 'Aguardando pagamento');
	}

	/* 
	 * Corresponde o Status do pedido no PagBank com o Status do pedido na loja
	 */
	public function correspondStatus($status_code)
	{
		switch ($status_code) {
			case 'WAITING':
				$status_loja = Configuration::get('PAGBANK_AWAITING_PAYMENT');
				break;
			case 'IN_ANALYSIS':
				$status_loja = Configuration::get('PAGBANK_IN_ANALYSIS');
				break;
			case 'PAID':
			case 'AVAILABLE':
				$status_loja = Configuration::get('PAGBANK_PAID');
				break;
			case 'AUTHORIZED':
				$status_loja = Configuration::get('PAGBANK_AUTHORIZED');
				break;
			case 'REFUNDED':
				$status_loja = Configuration::get('PAGBANK_REFUNDED');
				break;
			case 'CANCELED':
			case 'DECLINED':
				$status_loja = Configuration::get('PAGBANK_CANCELED');
				break;
		}
		return isset($status_loja) && $status_loja ? $status_loja : false;
	}

	/*
	 * Apaga Logs do banco de dados
	 */
	public function delete()
	{
		$id_log = Tools::getValue('id_log');
		$ps_logs_box = Tools::getValue('pagbank_logsBox');
		if (!$id_log && !$ps_logs_box) {
			return;
		}
		if (isset($ps_logs_box) && !is_array($ps_logs_box)) {
			$ps_logs_box = array($ps_logs_box);
		}
		$del_query = '';
		if (isset($id_log) && !empty($id_log)) {
			$del_query = 'DELETE FROM `' . _DB_PREFIX_ . 'pagbank_logs` WHERE `id_log` = ' . $id_log . ';';
		} else {
			foreach ($ps_logs_box as $id_logbox) {
				$del_query .= 'DELETE FROM `' . _DB_PREFIX_ . 'pagbank_logs` WHERE `id_log` = ' . $id_logbox . ';';
			}
		}
		if (!Db::getInstance()->execute($del_query)) {
			return false;
		}
		return true;
	}

	/*
	 * Envia chamada para a API
	*/
	public function curl_send($method, $post_url, $json_data = false, $timeout = 10, $id_cart = false, $recaptcha = false)
	{
		if ($json_data !== false && !$this->isJson($json_data)) {
			$this->saveLog('error', $method, $id_cart, $json_data, 'Invalid JSON String.', $post_url);
			return;
		}
		
		if (isset($id_cart) && strtoupper($method) === 'GET') {
			$info = $this->getOrderData($id_cart, 'id_cart');
			if (!empty($info) && $info['credential'] != '') {
				$credential = $info['credential'];
				$environment = $info['environment'];
				$token_api = $this->currentCredential($credential, $environment);
			} else {
				$token_api = $this->token;
			}
		} else {
			$token_api = $this->token;
		}

		$curl = curl_init();
		if ($json_data !== false && (strtoupper($method) === 'POST' || strtoupper($method) === 'PUT')) {
			$post_fields = ($json_data ? $json_data : '');
			if (strtoupper($method) === 'POST') {
				curl_setopt($curl, CURLOPT_POST, true);
			} else {
				curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
			}
			curl_setopt($curl, CURLOPT_POSTFIELDS, $post_fields);
		} else {
			curl_setopt($curl, CURLOPT_HTTPGET, true);
		}
		if ((bool)$recaptcha === true) {
			$header = array(
				'Accept: application/json',
				'Content-Type: application/json'
			);
		} else {
			$header = array(
				'Authorization: Bearer ' . $token_api,
				'Accept: application/json', 
				'Content-Type: application/json'
			);
		}
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_URL, $post_url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $timeout);
		$resp = curl_exec($curl);
		$info = curl_getinfo($curl);
		$error = curl_errno($curl);
		$error_message = curl_error($curl);
		$resp_object = json_decode($resp);

		curl_close($curl);

		if ((int)Configuration::get('PAGBANK_FULL_LOG') == 1) {
			if (isset($resp_object->error_messages)) {
				$this->saveLog('error', $method, $id_cart, $json_data, $resp, $post_url);
			} else {
				$this->saveLog('success', $method, $id_cart, $json_data, $resp, $post_url);
			}
		}

		if (in_array((int)$info['http_code'], array(200, 201, 204))) {
			$api_response = array(
				'errors' => false,
				'response' => $resp_object,
				'status' => $info['http_code'],
				'info' => $info,
			);
		} else {
			$this->ps_errors[] = 'A conexão com o PagBank retornou com erro: ' . $error . ' - ' . $error_message . ' (HTTP: ' . $info['http_code'] . ')';
			$errors = array();
			if (isset($resp_object->error_messages) && is_array($resp_object->error_messages)) {
				foreach ($resp_object->error_messages as $erro) {
					$errors[] = array(
						'error' => isset($erro->code) && $erro->code != '' ?  $erro->code : $erro->error,
						'description' => (string)$erro->description,
						'parameter' => isset($erro->parameter_name) ? (string)$erro->parameter_name : false
					);
				}
			}
			$api_response = array(
				'response' => $resp_object,
				'status' => $info['http_code'],
				'json_data' => $json_data,
				'info' => $info,
				'errors' => $errors
			);
		}
		return $api_response;
	}

	/*
	 * Cria / Salva a Chave Pública da API v.4 a partir do token
	*/
	public function getPublicKey()
	{
		if (!$this->token || $this->token === '') {
			return false;
		} else {
			$api_response = $this->curl_send('POST', $this->urls['api'] . 'public-keys', '{"type": "card"}', 30);
			$public_key_obj = $api_response['response'];
			if ($public_key_obj->public_key != '') {
				if ($this->environment == 1) {
					Configuration::updateValue('PAGBANK_PUBLIC_KEY', $public_key_obj->public_key, false);
				} else {
					Configuration::updateValue('PAGBANK_PUBLIC_KEY_SANDBOX', $public_key_obj->public_key, false);
				}
				return true;
			} else {
				return false;
			}
		}
	}

	/*
	* Verifica o Json
	*/
	private function isJson($string)
	{
		json_decode($string);
		return json_last_error() === JSON_ERROR_NONE;
	}

	/*
	 * Salva log com informações para análise/debug
	 */
	public function saveLog($type, $method, $id_cart = false, $data = false, $response = false, $url = false, $cron = 0)
	{
		if (!$response) {
			$response = '';
		}
		if (!$url) {
			$url = '';
		}
		if (!$id_cart) {
			$id_cart = 'NULL';
		}

		$clear_data = $this->removeSensitiveData($data);
		$clear_response = $this->removeSensitiveData($response);

		$query = 'INSERT INTO `' . _DB_PREFIX_ . 'pagbank_logs` 
		(`datetime`, 
		`type`, 
		`method`, 
		`id_shop`, 
		`id_cart`, 
		`data`, 
		`response`, 
		`url`, 
		`cron`)';
		$query .= ' VALUES 
		(NOW(), 
		"' . pSQL($type) . '", 
		"' . pSQL($method) . '", 
		' . (int)$this->shop_id . ', 
		' . $id_cart . ', 
		"' . addslashes($clear_data) . '", 
		"' . addslashes($clear_response) . '" , 
		"' . pSQL(addslashes($url)) . '", 
		' . $cron . ')';
		if (Db::getInstance()->execute($query) === false) {
			return false;
		}
		return true;
	}

	/*
	 * Remove Dados Sensíveis do Log
	 */
	public function removeSensitiveData($string)
	{
		$obj = json_decode($string);
		if (!is_object($obj)) {
			$clear_string = $string;
		} else {
			if (property_exists($obj, 'customer')) {
				$obj->customer = '#####';
			}
			if (property_exists($obj, 'items')) {
				$obj->items = '#####';
			}
			if (property_exists($obj, 'shipping')) {
				$obj->shipping = '#####';
			}
			if (property_exists($obj, 'access_token')) {
				$obj->access_token = '#####';
			}
			if (property_exists($obj, 'refresh_token')) {
				$obj->refresh_token = '#####';
			}
			if (property_exists($obj, 'code')) {
				$obj->code = '#####';
			}
			if (property_exists($obj, 'code_verifier')) {
				$obj->code_verifier = '#####';
			}
			if (property_exists($obj, 'account_id')) {
				$obj->account_id = '#####';
			}
			if (property_exists($obj, 'payment_method')) {
				if ($obj->payment_method->type === 'CREDIT_CARD') {
					$obj->payment_method->card = '#####';
					$obj->payment_method->holder = '#####';
				}
			}
			if (property_exists($obj, 'charges')) {
				if ($obj->charges[0]->payment_method->type === 'CREDIT_CARD') {
					$obj->charges[0]->payment_method->card = '#####';
					$obj->charges[0]->payment_method->holder = '#####';
				}
				if (isset($obj->charges[1]) && $obj->charges[1]->payment_method->type === 'CREDIT_CARD') {
					$obj->charges[1]->payment_method->card = '#####';
					$obj->charges[1]->payment_method->holder = '#####';	
				}
				if ($obj->charges[0]->payment_method->type === 'BOLETO') {
					$obj->charges[0]->payment_method->boleto->holder = '#####';
				}
			}
			if (property_exists($obj, 'name')) {
				$obj->name = '#####';
			}
			if (property_exists($obj, 'event')) {
				$obj->event = '#####';
			}
			if (property_exists($obj, 'tokenProperties')) {
				$obj->tokenProperties = '#####';
			}
			if (property_exists($obj, 'accountDefenderAssessment')) {
				$obj->accountDefenderAssessment = '#####';
			}
			$clear_string = json_encode($obj);
		}

		return $clear_string;
	}

	/*
	 * Gera número aleatório na referência do pedido 
	 */
	public function sortRefNumber()
	{
		$numbers = '0123456789';
		$max = strlen($numbers) - 1;
		$result = null;
		for ($i = 0; $i < 6; $i++) {
			$result .= $numbers[mt_rand(0, $max)];
		}
		return $result;
	}

	/*
	 * Gera uma hash para notificação
	 */
	public function getTokenHash() 
	{
		if (_PS_VERSION_ >= '1.7.0') {
			$token_hash = Tools::hashIV(_COOKIE_IV_);
		}else{
			$token_hash = Tools::encryptIV(_COOKIE_IV_);
		}

		return $token_hash;
	}

	/*
	 * Retorna IP do usuário
	 */
	public function getUserIp()
	{
		$ipaddress = '';
		if (isset($_SERVER['HTTP_CLIENT_IP'])) {
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		} elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		} elseif (isset($_SERVER['HTTP_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
		} elseif (isset($_SERVER['REMOTE_ADDR'])) {
			$ipaddress = $_SERVER['REMOTE_ADDR'];
		} else {
			$ipaddress = Tools::getRemoteAddr();
		}
		return $ipaddress;
	}

	/*
	 * Gera o desconto no carrinho de compras p/ pedido via Boleto
	 */
	public function generateCartRule($cart)
	{
		if (!$this->active) {
			return;
		}
		if (!$cart) {
			$cart = $this->context->cart;
		}
		$code = (int)($cart->id_customer) . '_PAGBANK_' . $cart->id;

		if (CartRule::cartRuleExists($code))
			return;

		$total = (float)Configuration::get('PAGBANK_DISCOUNT_VALUE');
		$discount_type = Configuration::get('PAGBANK_DISCOUNT_TYPE');
		$languages = Language::getLanguages();

		foreach ($languages as $key => $language) {
			if ($discount_type == 1) {
				$array_name[$language['id_lang']] = "Desconto de $total% no pedido";
			} else {
				$array_name[$language['id_lang']] = "Desconto de R$ $total no pedido";
			}
		}

		$voucher = new CartRule();
		$voucher->reduction_amount = ($discount_type == 2 ? $total : '');
		$voucher->reduction_percent = ($discount_type == 1 ? $total : '');
		$voucher->name = $array_name;
		$voucher->code = $code;
		$voucher->id_customer = (int)($cart->id_customer);
		$voucher->id_currency = (int)($cart->id_currency);
		$voucher->quantity = 1;
		$voucher->quantity_per_user = 1;
		$voucher->cumulable = 1;
		$voucher->cumulable_reduction = 1;
		$voucher->minimum_amount = 0;
		$voucher->active = 1;
		$now = time();
		$voucher->date_from = date("Y-m-d H:i:s", $now);
		$voucher->date_to = date("Y-m-d H:i:s", $now + (3600 * 24));
		if (!$voucher->validateFieldsLang(false) or !$voucher->add())
			die('Cupom não criado.');
		if (!$voucher->update())
			die('Cupom não atualizado.');
		if (!$cart->addCartRule((int)$voucher->id))
			die('Cupom não incluído no carrinho.');
	}

	/*
	 * Solicita a autorização da Aplicação e salva no banco
	 */
	public function getAppAuthorization($code, $app)
	{
		$app = (string)$app;
		if ($app === 'TAX') {
			$code_verifier = Configuration::get('PAGBANK_CODE_VERIFIER_TAX');
		} elseif ($app === 'D14') {
			$code_verifier = Configuration::get('PAGBANK_CODE_VERIFIER_D14');
		} elseif ($app === 'D30') {
			$code_verifier = Configuration::get('PAGBANK_CODE_VERIFIER_D30');
		}
		$api_info = $this->getApiInfo((int)$this->environment, $app);
		$criptogram = $api_info['cipher_text'];
		$redirect_uri = $this->urls['update'];
		$json_authorization = '{
			"grant_type": "authorization_code",
			"code": "' . $code . '",
			"redirect_uri": "' . $redirect_uri . '",
			"code_verifier": "' . $code_verifier . '"
		}';
		$post_url = $this->urls['appauth'];
		$header = array(
			'Authorization: Pub ' . $criptogram,
			'Accept: application/json', 
			'Content-Type: application/json'
		);
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $post_url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $json_authorization);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
		$resp = curl_exec($curl);
		$info = curl_getinfo($curl);
		$error = curl_errno($curl);
		$error_message = curl_error($curl);
		$resp_object = json_decode($resp);
		curl_close($curl);

		$expires = ((int)$resp_object->expires_in / 86400);
		$expire_date = date('Y-m-d', strtotime("+$expires days"));

		if (isset($resp_object->error_messages)) {

			return;
		
		} else {

			if ((int)$this->environment == 1){
				Configuration::updateValue('PAGBANK_TOKEN_'.$app, $resp_object->access_token, false);
				Configuration::updateValue('PAGBANK_TOKEN_EXPIRES_'.$app, $expire_date, false);
				Configuration::updateValue('PAGBANK_TOKEN_REFRESH_'.$app, $resp_object->refresh_token, false);
				Configuration::updateValue('PAGBANK_ACCOUNT_ID', $resp_object->account_id, false);
			} else {
				Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_'.$app, $resp_object->access_token, false);
				Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_EXPIRES_'.$app, $expire_date, false);
				Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_REFRESH_'.$app, $resp_object->refresh_token, false);
				Configuration::updateValue('PAGBANK_ACCOUNT_ID_SANDBOX', $resp_object->account_id, false);
			}

			$this->saveLog('app authorization', $app, false, $json_authorization, $resp, $post_url);

			return array(
				'info' => $info,
				'error' => $error,
				'error_msg' => $error_message,
				'resp' => $resp,
				'json_authorization' => $json_authorization,
			);

		}
	}

	/*
	 * Solicita a autorização da Aplicação e salva no banco
	 */
	public function refreshToken($refreshToken, $app)
	{
		$api_info = $this->getApiInfo((int)$this->environment, $app);
		$criptogram = $api_info['cipher_text'];
		$json_refresh = '{
			"grant_type": "refresh_token",
			"refresh_token": "' . $refreshToken . '"
		}';
		$post_url = $this->urls['refresh'];
		$header = array(
			'Authorization: Pub ' . $criptogram,
			'Accept: application/json', 
			'Content-Type: application/json'
		);
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $post_url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $json_refresh);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
		$resp = curl_exec($curl);
		$info = curl_getinfo($curl);
		$error = curl_errno($curl);
		$error_message = curl_error($curl);
		$resp_object = json_decode($resp);
		curl_close($curl);

		$expires = ((int)$resp_object->expires_in / 86400);
		$expire_date = date('Y-m-d', strtotime("+$expires days"));

		if (isset($resp_object->error_messages)) {

			return;
		
		} else {

			if ((int)$this->environment == 1){
				Configuration::updateValue('PAGBANK_TOKEN_'.$app, $resp_object->access_token, false);
				Configuration::updateValue('PAGBANK_TOKEN_EXPIRES_'.$app, $expire_date, false);
				Configuration::updateValue('PAGBANK_TOKEN_REFRESH_'.$app, $resp_object->refresh_token, false);
				Configuration::updateValue('PAGBANK_ACCOUNT_ID', $resp_object->account_id, false);
			} else {
				Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_'.$app, $resp_object->access_token, false);
				Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_EXPIRES_'.$app, $expire_date, false);
				Configuration::updateValue('PAGBANK_TOKEN_SANDBOX_REFRESH_'.$app, $resp_object->refresh_token, false);
				Configuration::updateValue('PAGBANK_ACCOUNT_ID_SANDBOX', $resp_object->account_id, false);
			}

			$this->saveLog('refresh token', $app, false, $json_refresh, $resp, $post_url);

			$this->getPublicKey();

			return array(
				'info' => $info,
				'error' => $error,
				'error_msg' => $error_message,
				'resp' => $resp,
				'json_authorization' => $json_refresh,
			);
		
		}
	}

	/*
	* Verifica se o token precisa ser atualizado
	*/
	public function callRefreshToken()
	{
		if($this->credential_type){
			$today = date('Y-m-d', time());
			if ((int)$this->environment == 1){
				$token_expires = Configuration::get('PAGBANK_TOKEN_EXPIRES_'.$this->credential_type);
				$token_refresh = Configuration::get('PAGBANK_TOKEN_REFRESH_'.$this->credential_type);
			} else {
				$token_expires = Configuration::get('PAGBANK_TOKEN_SANDBOX_EXPIRES_'.$this->credential_type);
				$token_refresh = Configuration::get('PAGBANK_TOKEN_SANDBOX_REFRESH_'.$this->credential_type);
			}

			if (!empty($token_expires) && !empty($token_refresh) && (strtotime($today) >= strtotime($token_expires)) ||
				empty($this->account_id) || $this->account_id === 'NULL') {
				$this->refreshToken($token_refresh, $this->credential_type);
			}
		}
	}

	/*
	* Valida o nome do estado
	*/
	public function getStateByIsoCode($uf = false, $param = false)
	{
		$id_country = Country::getIdByName($this->context->language->id, 'Brasil');
		if (!$id_country || (int)$id_country < 1) {
			$id_country = Country::getIdByName($this->context->language->id, 'Brazil');
		}
		if (!$id_country || (int)$id_country < 1) {
			$id_country = 58;
		}
		$states = State::getStatesByIdCountry($id_country);
		$estados = array();
		foreach ($states as $item) {
			$estados[$item['iso_code']] = $item;
		}

		if ($uf != false) {
			if ($param != false) {
				$api_response = $estados[$uf][$param];
			} else {
				$api_response = $estados[$uf];
			}
		} else {
			$api_response = $estados;
		}
		return isset($api_response) && $api_response ? $api_response : false;
	}

	/*
	* Calcula horas/minutos
	*/
	public function hoursMinutes($time_minutes)
	{
		if ($time_minutes < 1) {
			return;
		}
		$hours = floor($time_minutes / 60);
		$minutes = ($time_minutes % 60);
		return array('hours' => $hours, 'minutes' => $minutes);
	}

	/*
	* Verifica se o prazo fornecido é em horas ou minutos
	*/
	public function calculateDeadline($deadline)
	{
		$time = array();
		if ($deadline > 60) {
			$array_time = $this->hoursMinutes($deadline);
			$time['deadline'] = array(
				'hours' => $array_time['hours'],
				'minutes' => $array_time['minutes']
			);
		} else {
			$time['deadline'] = array(
				'hours' => 0,
				'minutes' => $deadline
			);
		}

		return $time['deadline'];
	}

	/*
	* Insere no banco o cartão criptografado
	*/
	public function insertCustomerToken($info)
	{
		$ins_query = 'INSERT INTO `' . _DB_PREFIX_ . 'pagbank_customer_token` 
		(`id_shop`, 
		`id_customer`, 
		`card_name`, 
		`card_brand`, 
		`card_first_digits`, 
		`card_last_digits`, 
		`card_month`, 
		`card_year`, 
		`card_token`, 
		`date_add`) ';
		$ins_query .= ' VALUES 
		(' . (int)$this->shop_id . ', 
		' . (int)$info['id_customer'] . ', 
		"' . pSQL($info['card_name']) . '", 
		"' . pSQL($info['card_brand']) . '", 
		' . (int)$info['card_first_digits'] . ', 
		' . (int)$info['card_last_digits'] . ', 
		"' . pSQL($info['card_month']) . '", 
		' . (int)$info['card_year'] . ', 
		"' . pSQL($info['card_token']) . '", 
		"' . date("Y-m-d H:i:s") . '")';
		if (!Db::getInstance()->execute($ins_query)) {
			$this->saveLog('error', 'insertCustomerToken', $info['id_customer'], $ins_query, 'Cartão Criptografado não salvo no banco.');
			return false;
		}
		return true;
	}

	/*
	* Seleciona o cliente pelo cartão criptografado
	*/
	public function getCustomerToken($id_customer, $id_customer_token = false)
	{
		$get_query = 'SELECT * FROM `' . _DB_PREFIX_ . 'pagbank_customer_token` WHERE 
		(`id_shop` = ' . (int)$this->shop_id . ' OR `id_shop` IS NULL) AND 
		`id_customer` = ' . (int)$id_customer;
		if ($id_customer_token && (int)$id_customer_token > 0) {
			$get_query .= ' AND `id_customer_token` = ' . (int)$id_customer_token;
		}
		$return = Db::getInstance()->executeS($get_query);
		if (!$return) {
			return false;
		}
		return $return;
	}

	/*
	* Seleciona o cartão criptografado do cliente
	*/
	public function getCardToken($id_customer_token)
	{
		$get_query = 'SELECT `card_token` FROM `' . _DB_PREFIX_ . 'pagbank_customer_token` WHERE 
		(`id_shop` = ' . (int)$this->shop_id . ' OR `id_shop` IS NULL) AND 
		`id_customer` = ' . (int)$this->context->cart->id_customer . ' AND 
		`id_customer_token` = ' . (int)$id_customer_token;
		$return = Db::getInstance()->getValue($get_query);
		if (!$return) {
			$this->saveLog('error', 'getCardToken', $id_customer_token, $get_query, 'Erro ao consultar os dados de cartão salvos para o cliente.');
			return false;
		}
		return $return;
	}

	/*
	* Deleta o cartão criptografado do cliente
	*/
	public function deleteCustomerToken($id_customer_token)
	{
		$delete_query = 'DELETE FROM `' . _DB_PREFIX_ . 'pagbank_customer_token` WHERE 
		(`id_shop` = ' . (int)$this->shop_id . ' OR `id_shop` IS NULL) AND 
		`id_customer` = ' . (int)$this->context->cart->id_customer . ' AND 
		`id_customer_token` = ' . (int)$id_customer_token;
		if (!Db::getInstance()->execute($delete_query)) {
			$this->saveLog('error', 'delete', $id_customer_token, $delete_query, 'Erro ao apagar cartão criptografado do banco.');
			return false;
		}
		return 'OK';
	}

	/*
	* Gera o code challenge a partir da chave criptográfica do sistema
	*/
	public function getPkceData($type, $item)
	{
		$verifier_bytes = Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $this->name . '.' . $type . '.' . Tools::getAdminTokenLite("AdminPagBank");
		$code_verifier = rtrim(strtr(base64_encode($verifier_bytes), "+/", "-_"), "=");
		$challenge_bytes = hash("sha256", $code_verifier, true);
		$code_challenge = rtrim(strtr(base64_encode($challenge_bytes), "+/", "-_"), "=");

		$pkce = array(
			'code_verifier' => $code_verifier,
			'code_challenge' => $code_challenge,
		);
		return $pkce[$item];
	}

	/*
	* Remove caracteres especiais da string
	*/
	public function replaceSpecialChars($str)
	{

		$a = array(
			'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ',
			'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í',
			'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć',
			'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ',
			'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ',
			'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ',
			'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š',
			'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ',
			'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ',
			'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ', 'Ά', 'ά', 'Έ', 'έ', 'Ό', 'ό', 'Ώ', 'ώ', 'Ί',
			'ί', 'ϊ', 'ΐ', 'Ύ', 'ύ', 'ϋ', 'ΰ', 'Ή', 'ή', '(', ')', 'º', 'ª', '"', '°', '–'
		);

		$b = array(
			'A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O',
			'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i',
			'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C',
			'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G',
			'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ',
			'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n',
			'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's',
			'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y',
			'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U',
			'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o', 'Α', 'α', 'Ε', 'ε', 'Ο', 'ο', 'Ω', 'ω', 'Ι',
			'ι', 'ι', 'ι', 'Υ', 'υ', 'υ', 'υ', 'Η', 'η', '- ', '', 'o', 'a', '', '', '-'
		);

		return str_replace($a, $b, $str);
	}
}
