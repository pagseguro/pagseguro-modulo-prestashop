{*
 * PagBank
 * 
 * Módulo Oficial para Integração com o PagBank via API v.4
 * Checkout Transparente para PrestaShop 1.6.x ao 9.x
 * Pagamento com Cartão de Crédito, Google Pay, Pix, Boleto e Pagar com PagBank
 * 
 * @author
 * 2011-2026 PrestaBR - https://prestabr.com.br
 * 
 * @copyright
 * 1996-2026 PagBank - https://pagbank.com.br
 * 
 * @license
 * Open Software License 3.0 (OSL 3.0) - https://opensource.org/license/osl-3-0-php/
 *
 *}

<div class="panel">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-lg-12 text-left pagbanklogs-header">
			<h2>{l s='Ver Log' mod='pagbank'}</h2>
			<img src="../modules/pagbank/img/pagbank-logo-animado_35px.gif" class="img-responsive" />
		</div>
	</div>
</div>
<div class="panel">
	<div class="panel-heading">
		({$log->id_log}) {l s='Data:' mod='pagbank'} <b>{$log->datetime|date_format:'%d/%m/%Y %H:%M:%S'}</b> -
		{l s='Tipo: ' mod='pagbank'} <b>{$log->type}</b> - {l s='Método: ' mod='pagbank'} <b>{$log->method}</b>
	</div>
	<div class="panel-body">
		{if isset($log->id_cart) && $log->id_cart > 0}
			<div class="box row clearfix">
				<h3>{l s='ID do Carrinho' mod='pagbank'}: <a
						href="{$link->getAdminLink('AdminCarts')}&id_cart={$log->id_cart}&viewcart" id="id_cart"
						target="_blank">{$log->id_cart}</a></h3>
			</div>
			<br />
		{/if}
		{if isset($url) && $url != ''}
			<div class="box row clearfix">
				<h3>{l s='URL Chamada' mod='pagbank'}</h3>
				<pre id="url-called">{$url|escape:'htmlall':'UTF-8'}</pre>
			</div>
			<br />
		{/if}
		{if $log->method != 'callback'}
			<div class="box row clearfix">
				<h3>{l s='Dados enviados' mod='pagbank'}</h3>
				<pre id="sent-data" class="data_format">{$data|escape:'htmlall':'UTF-8'}</pre>
			</div>
			<br /><br />
		{/if}
		<div class="box row clearfix">
			<h3>{l s='Resposta da API' mod='pagbank'}</h3>
			<pre id="response-data" class="data_format">{$response|escape:'htmlall':'UTF-8'}</pre>
		</div>
	</div>
	<div class="panel-footer">
		<a class="btn btn-default" href="{$back_link}" title="{l s='Back to logs list' mod='pagbank'}">
			<i class="process-icon-back"></i>
			{l s='Voltar para lista de LOGs' mod='pagbank'}
		</a>
	</div>
</div>