<?php

include_once dirname(__FILE__) . '/../../init.php';
include_once dirname(__FILE__) . '/../../config/config.inc.php';
include_once dirname(__FILE__) . '/pagseguro.php';
include_once dirname(__FILE__) . '/features/modules/pagsegurofactoryinstallmodule.php';
include_once dirname(__FILE__) . '/features/payment/pagseguropaymentorderprestashop.php';
include_once dirname(__FILE__) . '/features/util/encryptionIdPagSeguro.php';
include_once dirname(__FILE__) . '/features/library/vendor/autoload.php';

