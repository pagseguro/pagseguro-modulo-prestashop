<?php
var_dump(getcwd());
include_once 'vendor/autoload.php';
\PagSeguro\Library::initialize();
//echo "oi";