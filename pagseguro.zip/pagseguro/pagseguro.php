<?php

/*
 * 2007-2013 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author PrestaShop SA <contact@prestashop.com>
 *  @copyright  2007-2013 PrestaShop SA
 *  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
include_once dirname(__FILE__) . '/features/PagSeguroLibrary/PagSeguroLibrary.php';
include_once dirname(__FILE__) . '/features/modules/pagsegurofactoryinstallmodule.php';
// include_once dirname(__FILE__) . '/menu/conciliacao.php';

if (! defined('_PS_VERSION_')) {
    exit();
}

class PagSeguro extends PaymentModule
{
    private $modulo;

    protected $errors = array();

    private $html;

    public $context;

    public function __construct()
    {
        $this->name = 'pagseguro';
        $this->tab = 'payments_gateways';
        $this->version = '1.8';
        $this->author = 'PagSeguro Internet LTDA.';
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
        
        parent::__construct();
        
        $this->displayName = $this->l('PagSeguro');
        $this->description = $this->l('Receba pagamentos por cartão de crédito, transferência bancária e boleto.');
        $this->confirmUninstall = $this->l('Tem certeza que deseja remover este módulo?');
        
        if (version_compare(_PS_VERSION_, '1.5.0.2', '<')) {
            include_once (dirname(__FILE__) . '/backward_compatibility/backward.php');
        }
        
        $this->modulo = PagSeguroFactoryInstallModule::createModule(_PS_VERSION_);
        
    }
    
    public function install()
    {
        if (version_compare(PagSeguroLibrary::getVersion(), '2.1.8', '<=')) {
            if (! $this->validatePagSeguroRequirements()) {
                return false;
            }
        }
        
        if (! $this->generatePagSeguroOrderStatus()) {
            return false;
        }
        
        if (! $this->createTables()) {
            return false;
        }
        
        if (! $this->modulo->installConfiguration()) {
            return false;
        }
        
        if (! parent::install() or ! $this->registerHook('payment') or
            ! $this->registerHook('paymentReturn') or
            ! Configuration::updateValue('PAGSEGURO_EMAIL', '') or
            ! Configuration::updateValue('PAGSEGURO_TOKEN', '') or
            ! Configuration::updateValue('PAGSEGURO_URL_REDIRECT', '') or
            ! Configuration::updateValue('PAGSEGURO_NOTIFICATION_URL', '') or
            ! Configuration::updateValue('PAGSEGURO_CHARSET', PagSeguroConfig::getData('application', 'charset')) or
            ! Configuration::updateValue('PAGSEGURO_LOG_ACTIVE', PagSeguroConfig::getData('log', 'active')) or
            ! Configuration::updateValue('PAGSEGURO_RECOVERY_ACTIVE', false) or
            ! Configuration::updateValue('PAGSEGURO_DAYS_RECOVERY', '') or
            ! Configuration::updateValue('PAGSEGURO_CHECKOUT', false) or
            ! Configuration::updateValue(
                'PAGSEGURO_LOG_FILELOCATION',
                PagSeguroConfig::getData('log', 'fileLocation')
            )) {
            return false;
        }
        return true;
    }

    public function uninstall()
    {
        if (! $this->modulo->uninstallConfiguration()) {
            return false;
        }
        
        if (! Configuration::deleteByName('PAGSEGURO_EMAIL')
        or ! Configuration::deleteByName('PAGSEGURO_TOKEN')
        or ! Configuration::deleteByName('PAGSEGURO_URL_REDIRECT')
        or ! Configuration::deleteByName('PAGSEGURO_NOTIFICATION_URL')
        or ! Configuration::deleteByName('PAGSEGURO_CHARSET')
        or ! Configuration::deleteByName('PAGSEGURO_LOG_ACTIVE')
        or ! Configuration::deleteByName('PAGSEGURO_RECOVERY_ACTIVE')
        or ! Configuration::deleteByName('PAGSEGURO_DAYS_RECOVERY')
        or ! Configuration::deleteByName('PAGSEGURO_LOG_FILELOCATION')
        or ! Configuration::deleteByName('PS_OS_PAGSEGURO')
		or ! Configuration::deleteByName('PAGSEGURO_CHECKOUT')
        or ! parent::uninstall()) {
            return false;
        }

        return true;
    }

    public function getContent()
    {
        if (Tools::isSubmit('btnSubmit')) {
            
            $this->postValidation();
            
            if (! count($this->errors)) {
                $this->postProcess();
            } else {
                foreach ($this->errors as $error) {
                    $this->html .= '<div class="module_error alert error" '.$this->getWidthVersion(_PS_VERSION_).'">'
                        . $error . '</div>';
                }
            }
        }
        
        $this->html .= $this->displayForm();
        
        return $this->html;
    }
    
    private function getConfigurationTabHtml()
    {
        global $smarty;
        
        $charset = Util::getCharsetOptions();
        $optionCharset = "";
        $selection = array_search(
            Configuration::get('PAGSEGURO_CHARSET'),
            Util::getCharsetOptions()
        );
    
        foreach ($charset as $key => $value){
            
            if ($key == $selection) {
                $optionCharset .= "<option value='" . $key . "' selected='selected' >" . $value . "</option>";
            } else {
                $optionCharset .= "<option value='" . $key . "'>" . $value . "</option>";
            }
        }
    
        $checkout = Util::getTypeCheckout();
        $optionCheckout = "";
        $selection = Configuration::get('PAGSEGURO_CHECKOUT');
    
        foreach ($checkout as $key => $value){
            if ($key == $selection) {
                $optionCheckout .= "<option value='" . $key . "' selected='selected' >" . $value . "</option>";
            } else {
                $optionCheckout .= "<option value='" . $key . "'>" . $value . "</option>";
            }
        }
        
        $smarty->assign('optionCharset', $optionCharset);
        $smarty->assign('optionCheckout', $optionCheckout);
        $smarty->assign('email', Tools::safeOutput(Configuration::get('PAGSEGURO_EMAIL')));
        $smarty->assign('token', Tools::safeOutput(Configuration::get('PAGSEGURO_TOKEN')));
        $smarty->assign('titulo', $this->l('Configuração'));
        
        $conteudo = '';
        $conteudo = $this->display(dirname(__FILE__), '/menu/configuracoes.tpl');
        return $conteudo;
    
    }
    
    private function getExtrasTabHtml()
    {
        global $smarty;
        
        $active = Util::getActive();
        $optionLog = "";
        $selection = Configuration::get('PAGSEGURO_LOG_ACTIVE');
    
        foreach ($active as $key => $value){
            if ($key == $selection) {
                $optionLog .= "<option value='" . $key . "' selected='selected' >" . $value . "</option>";
            } else {
                $optionLog .= "<option value='" . $key . "'>" . $value . "</option>";
            }
        }
    
        $optionRecovery = "";
        $selection = Configuration::get('PAGSEGURO_RECOVERY_ACTIVE');
    
        foreach ($active as $key => $value){
            if ($key == $selection) {
                $optionRecovery .= "<option value='" . $key . "' selected='selected' >" . $value . "</option>";
            } else {
                $optionRecovery .= "<option value='" . $key . "'>" . $value . "</option>";
            }
        }
    
        $validLink = "";
        $selection = Tools::safeOutput(Configuration::get('PAGSEGURO_DAYS_RECOVERY'));
    
        foreach (Util::getDaysRecovery() as  $key => $value) {
            if ($key == $selection) {
                $validLink .= "<option value='" . $key . "' selected='selected' >" . $value . "</option>";
            } else {
                $validLink .= "<option value='" . $key . "'>" . $value . "</option>";
            }
        }

        $smarty->assign('optionLog', $optionLog);
        $smarty->assign('optionRecovery', $optionRecovery);
        $smarty->assign('validLink', $validLink);
        $smarty->assign('urlNotification', $this->getNotificationUrl());
        $smarty->assign('urlRedirection', $this->getDefaultRedirectionUrl());
        $smarty->assign('fileLocation', Tools::safeOutput(Configuration::get('PAGSEGURO_LOG_FILELOCATION')));
        $smarty->assign('titulo', $this->l('Extras'));

        $conteudo = "";
        $conteudo = $this->display(dirname(__FILE__), '/menu/extras.tpl');
        return $conteudo;
    }
    
    private function getConciliationTabHtml()
    {
        global $smarty;
        
        $dias = "";
        $image = '../modules/pagseguro/assets/images/';
         
        foreach (Util::getDaysSearch() as $value ) {
            $dias .= "<option value='" . $value . "'>" . $value . "</option>";
        }
        
        $adminToken = Tools::getAdminTokenLite('AdminOrders');

        $tableResult = include_once(dirname(__FILE__) . '\menu\conciliacao.php');

        $smarty->assign('dias', $dias);
        $smarty->assign('urlAdminOrder', $_SERVER['SCRIPT_NAME'].'?tab=AdminOrders');
        $smarty->assign('adminToken', $adminToken);
        $smarty->assign('tableResult', $tableResult['tabela']);
        $smarty->assign('titulo', $this->l('Conciliação'));
        $smarty->assign('errorMsg', $tableResult['errorMsg']);

        $conteudo = "";
//         $conteudo .= include(dirname(__FILE__) . '\menu\conciliacao.phtml');
//         $conteudo .= include(dirname(__FILE__) . '\menu\conciliacao.tpl');
        $conteudo = $this->display(dirname(__FILE__), '/menu/conciliacao.tpl');
        return $conteudo;
    
    }

    private function getRequirementsTabHtml()
    {
        global $smarty;
        
        $image = '../modules/pagseguro/assets/images/';
        $error = array();
    
        $validation = PagSeguroConfig::validateRequirements();
        foreach ($validation as $key => $value) {
            if(strlen($value) == 0) {
                $error[$key][0] = $image.'ok.png';
                $error[$key][1] = null;
            } else {
                $error[$key][0] = $image.'delete.png';
                $error[$key][1] = $value;
            }
        }
    
        $currency = self::returnIdCurrency();
        /* Currency validation */
        if (!$currency) {
            $error['moeda'][0] = $image.'delete.png';
            $error['moeda'][1] = $this->missedCurrencyMessage();
        } else {
            $error['moeda'][0] = $image.'ok.png';
            $error['moeda'][1] = "Moeda REAL instalada.";
        }

        $error['curl'][1] = (is_null($error['curl'][1]) ? "Biblioteca cURL instalada." : $error['curl'][1]);
        $error['dom'][1] = (is_null($error['dom'][1]) ? "DOM XML instalado." : $error['dom'][1]);
        $error['spl'][1] = (is_null($error['spl'][1]) ? "Biblioteca padrão do PHP(SPL) instalada." : $error['spl'][1]);
        $error['version'][1] = (is_null($error['version'][1]) ? "Versão do PHP superior à 5.1.6." : $error['version'][1]);

        $smarty->assign('error', $error);
        $smarty->assign('titulo', $this->l('Requisitos'));

        $conteudo = "";
        $conteudo = $this->display(dirname(__FILE__), '/menu/requerimentos.tpl');
        return $conteudo;
    
    }
    
    private function displayForm()
    {
        global $smarty;
        
        $smarty->assign('module_dir', _PS_MODULE_DIR_ . 'pagseguro/');
        $smarty->assign('action_post', Tools::htmlentitiesUTF8($_SERVER['REQUEST_URI']));
        $smarty->assign('email_user', Tools::safeOutput(Configuration::get('PAGSEGURO_EMAIL')));
        $smarty->assign('token_user', Tools::safeOutput(Configuration::get('PAGSEGURO_TOKEN')));
        $smarty->assign('redirect_url', $this->getDefaultRedirectionUrl());
        $smarty->assign('notification_url', $this->getNotificationUrl());
        $smarty->assign('charset_options', Util::getCharsetOptions());
        $smarty->assign(
            'charset_selected',
            array_search(
                Configuration::get('PAGSEGURO_CHARSET'),
                Util::getCharsetOptions()
            )
        );
        $smarty->assign('active_log', Util::getActive());
        $smarty->assign('type_checkout', Util::getTypeCheckout());
        $smarty->assign('checkout_selected', Configuration::get('PAGSEGURO_CHECKOUT'));
        $smarty->assign('log_selected', Configuration::get('PAGSEGURO_LOG_ACTIVE'));
        $smarty->assign('recovery_selected', Configuration::get('PAGSEGURO_RECOVERY_ACTIVE'));
        $smarty->assign('diretorio_log', Tools::safeOutput(Configuration::get('PAGSEGURO_LOG_FILELOCATION')));
        $smarty->assign('days_recovery', Configuration::get('PAGSEGURO_DAYS_RECOVERY'));
        $smarty->assign('checkActiveSlide', Tools::safeOutput($this->checkActiveSlide()));
        $smarty->assign('css_version', $this->getCssDisplay());
    
        $smarty->assign(array(
            'tab' => array(
                'config' => array(
                    'title' => $this->l('Configuração'),
                    'content' => $this->getConfigurationTabHtml(),
                    'icon' => '',
                    'tab' => 1,
                    'selected' => true,
                ),
                'extras' => array(
                    'title' => $this->l('Extras'),
                    'content' => $this->getExtrasTabHtml(),
                    'icon' => '',
                    'tab' => 2,
                    'selected' => false,
                ),
                'conciliation' => array(
                    'title' => $this->l('Conciliação'),
                    'content' => $this->getConciliationTabHtml(),
                    'icon' => '',
                    'tab' => 3,
                    'selected' => false,
                ),
                'requirements' => array(
                    'title' => $this->l('Requisitos'),
                    'content' => $this->getRequirementsTabHtml(),
                    'icon' => '',
                    'tab' => 4,
                    'selected' => false,
                ),
            )
        ));
    
        return $this->display(__PS_BASE_URI__ . 'modules/pagseguro', 'admin_pagseguro.tpl');
    }
    
    /**
     * Realize post validations according with PagSeguro standards
     * case any inconsistence, an item is added to $_postErrors
     */
    private function postValidation()
    {
        if (Tools::isSubmit('btnSubmit')) {
            
            $email = Tools::getValue('pagseguro_email');
            $token = Tools::getValue('pagseguro_token');
            $pagseguro_url_redirect = Tools::getValue('pagseguro_url_redirect');
            $pagseguro_notification_url = Tools::getValue('pagseguro_notification_url');
            $charset = Tools::getValue('pagseguro_charset');
            $pagseguro_log = Tools::getValue('pagseguro_log');
            $pagseguro_checkout = Tools::getValue('pagseguro_checkout');
            $pagseguro_recovery = Tools::getValue('pagseguro_days_recovery');
            
            /* E-mail validation */
            if (! $email) {
                $this->errors[] = $this->errorMessage('E-MAIL');
            } elseif (Tools::strlen($email) > 60) {
                $this->errors[] = $this->invalidFieldSizeMessage('E-MAIL');
            } elseif (! Validate::isEmail($email)) {
                $this->errors[] = $this->invalidMailMessage('E-MAIL');
            }
            
            /* Token validation */
            if (! $token) {
                $this->errors[] = $this->errorMessage('TOKEN');
            } elseif (strlen($token) != 32) {
                $this->errors[] = $this->invalidFieldSizeMessage('TOKEN');
            }
            
            /* URL redirect validation */
            if ($pagseguro_url_redirect && ! filter_var($pagseguro_url_redirect, FILTER_VALIDATE_URL)) {
                $this->errors[] = $this->invalidUrl('URL DE REDIRECIONAMENTO');
            }
            
            /* Notification url validation */
            if ($pagseguro_notification_url && ! filter_var($pagseguro_notification_url, FILTER_VALIDATE_URL)) {
                $this->errors[] = $this->invalidUrl('URL DE NOTIFICAÇÃO');
            }
            
            /* Charset validation */
            if (! array_key_exists($charset, Util::getCharsetOptions())) {
                $this->errors[] = $this->invalidValue('CHARSET');
            }
            
            /* Log validation */
            if (! array_key_exists($pagseguro_log, Util::getActive())) {
                $this->errors[] = $this->invalidValue('LOG');
            }
        }
    }

    /**
     * Realize PagSeguro database keys values
     */
    private function postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            
            $charsets = Util::getCharsetOptions();
            
            Configuration::updateValue('PAGSEGURO_EMAIL', Tools::getValue('pagseguro_email'));
            Configuration::updateValue('PAGSEGURO_TOKEN', Tools::getValue('pagseguro_token'));
            Configuration::updateValue('PAGSEGURO_URL_REDIRECT', Tools::getValue('pagseguro_url_redirect'));
            Configuration::updateValue('PAGSEGURO_NOTIFICATION_URL', Tools::getValue('pagseguro_notification_url'));
            Configuration::updateValue('PAGSEGURO_CHARSET', $charsets[Tools::getValue('pagseguro_charset')]);
            Configuration::updateValue('PAGSEGURO_LOG_ACTIVE', Tools::getValue('pagseguro_log'));
            Configuration::updateValue('PAGSEGURO_CHECKOUT', Tools::getValue('pagseguro_checkout'));
            Configuration::updateValue('PAGSEGURO_LOG_FILELOCATION', Tools::getValue('pagseguro_log_dir'));
            
            /* Verify if log file exists, case not try create */
            if (Tools::getValue('pagseguro_log')) {
                $this->verifyLogFile(Tools::getValue('pagseguro_log_dir'));
            }
        }
        $this->html .= '<div class="module_confirmation conf confirm" '.$this->getWidthVersion(_PS_VERSION_).' ">'
            . $this->l('Dados atualizados com sucesso') . '</div>';
    }
    
    private function getWidthVersion($module_version)
    {
        return version_compare($module_version, '1.5', '<') ? 'style="width: 896px;' : 'style="width: 935px;';
    }
    

    private function errorMessage($field)
    {
        return sprintf($this->l('O campo <strong>%s</strong> deve ser informado.'), $field);
    }

    private function missedCurrencyMessage()
    {
        return sprintf(
            $this->l(
                'Verifique se a moeda <strong>REAL</strong> esta instalada e ativada.
                Para importar a moeda vá em Localização e importe "Brazil" no Pacote de Localização, 
                após isso, vá em localização, moedas, e habilite o <strong>REAL</strong>.<br>
                O PagSeguro aceita apenas BRL (Real) como moeda de pagamento.'
            )
        );
    }

    private function invalidMailMessage($field)
    {
        return sprintf($this->l('O campo <strong>%s</strong> deve ser conter um email válido.'), $field);
    }

    private function invalidFieldSizeMessage($field)
    {
        return sprintf($this->l('O campo <strong>%s</strong> está com um tamanho inválido'), $field);
    }

    private function invalidValue($field)
    {
        return sprintf($this->l('O campo <strong>%s</strong> contém um valor inválido.'), $field);
    }

    private function invalidUrl($field)
    {
        return sprintf($this->l('O campo <strong>%s</strong> deve conter uma url válida.'), $field);
    }

    private function checkActiveSlide()
    {
        return Tools::getValue('activeslide') ? Tools::getValue('activeslide') : 1;
    }

    public static function returnIdCurrency($value = 'BRL')
    {
        $sql = 'SELECT `id_currency`
        FROM `' . _DB_PREFIX_ . 'currency`
        WHERE `deleted` = 0 
        AND `iso_code` = "' . $value . '"';
        
        $id_currency = (Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql));
        return empty($id_currency) ? 0 : $id_currency[0]['id_currency'];
    }

    public function hookPayment($params)
    {
        
        if (! $this->active) {
            return;
        }
        
        $this->modulo->paymentConfiguration($params);
        return $this->display(__PS_BASE_URI__ . 'modules/pagseguro', '/views/templates/hook/payment.tpl');
    }

    public function hookPaymentReturn($params)
    {
        $this->modulo->returnPaymentConfiguration($params);
        return $this->display(__PS_BASE_URI__ . 'modules/pagseguro', '/views/templates/hook/payment_return.tpl');
    }

    private function validatePagSeguroRequirements()
    {
        $condional = true;
        
        foreach (PagSeguroConfig::validateRequirements() as $value) {
            if (! Tools::isEmpty($value)) {
                $condional = false;
                $this->errors[] = Tools::displayError($value);
            }
        }
        
        if (! $condional) {
            $this->html = $this->displayError(implode('<br />', $this->errors));
        }
        
        return $condional;
    }

    private function createTables()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pagseguro_order` (
            `id` int(11) unsigned NOT NULL auto_increment,
            `id_transaction` varchar(255) NOT NULL,
            `id_order` int(10) unsigned NOT NULL ,
            PRIMARY KEY  (`id`)
            ) ENGINE=' . _MYSQL_ENGINE_ .
             ' DEFAULT CHARSET=utf8  auto_increment=1;';
        
        if (! Db::getInstance()->Execute($sql)) {
            return false;
        }
        return true;
    }

    private function generatePagSeguroOrderStatus()
    {
        $orders_added = true;
        $name_state = null;
        $image = _PS_ROOT_DIR_ . '/modules/pagseguro/logo.gif';
        
        foreach (Util::getCustomOrderStatusPagSeguro() as $key => $statusPagSeguro) {
            
            $order_state = new OrderState();
            $order_state->module_name = 'pagseguro';
            $order_state->send_email = $statusPagSeguro['send_email'];
            $order_state->color = '#95D061';
            $order_state->hidden = $statusPagSeguro['hidden'];
            $order_state->delivery = $statusPagSeguro['delivery'];
            $order_state->logable = $statusPagSeguro['logable'];
            $order_state->invoice = $statusPagSeguro['invoice'];
            
            if (version_compare(_PS_VERSION_, '1.5', '>')) {
                $order_state->unremovable = $statusPagSeguro['unremovable'];
                $order_state->shipped = $statusPagSeguro['shipped'];
                $order_state->paid = $statusPagSeguro['paid'];
            }
            
            $order_state->name = array();
            $order_state->template = array();
            $continue = false;
            
            foreach (Language::getLanguages(false) as $language) {
                
                $list_states = $this->findOrderStates($language['id_lang']);
                
                $continue = $this->checkIfOrderStatusExists(
                    $language['id_lang'],
                    $statusPagSeguro['name'],
                    $list_states
                );
                
                if ($continue) {
                    $order_state->name[(int) $language['id_lang']] = $statusPagSeguro['name'];
                    $order_state->template[$language['id_lang']] = $statusPagSeguro['template'];
                }
                
                if ($key == 'WAITING_PAYMENT' or $key == 'IN_ANALYSIS') {
                    
                    $this->copyMailTo($statusPagSeguro['template'], $language['iso_code'], 'html');
                    $this->copyMailTo($statusPagSeguro['template'], $language['iso_code'], 'txt');
                }
                
            }
            
            if ($continue) {
                
                if ($order_state->add()) {
                    
                    $file = _PS_ROOT_DIR_ . '/img/os/' . (int) $order_state->id . '.gif';
                    copy($image, $file);
                    
                }
            }
            
            if ($key == 'INITIATED') {
                $name_state = $statusPagSeguro['name'];
            }
        }
        
        Configuration::updateValue('PS_OS_PAGSEGURO', $this->returnIdOrderByStatusPagSeguro($name_state));
        
        return $orders_added;
    }
    
    private function copyMailTo($name, $lang, $ext)
    {
        
        $template = _PS_MAIL_DIR_.$lang.'/'.$name.'.'.$ext;
        
        if (! file_exists($template)) {
            
            $templateToCopy = _PS_ROOT_DIR_ . '/modules/pagseguro/mails/' . $name .'.'. $ext;
            copy($templateToCopy, $template);
            
        }
    }
    
    private function findOrderStates($lang_id)
    {
        $sql = 'SELECT DISTINCT osl.`id_lang`, osl.`name`
            FROM `' . _DB_PREFIX_ . 'order_state` os
            INNER JOIN `' .
             _DB_PREFIX_ . 'order_state_lang` osl ON (os.`id_order_state` = osl.`id_order_state`)
            WHERE osl.`id_lang` = '."$lang_id".' AND osl.`name` in ("Iniciado","Aguardando pagamento",
            "Em análise", "Paga","Disponível","Em disputa","Devolvida","Cancelada") AND os.`id_order_state` <> 6';
        
        return (Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql));
    }

    private function returnIdOrderByStatusPagSeguro($nome_status)
    {
        
        $isDeleted = version_compare(_PS_VERSION_, '1.5', '<') ? '' : 'WHERE deleted = 0';
        
        $sql = 'SELECT distinct os.`id_order_state`
            FROM `' . _DB_PREFIX_ . 'order_state` os
            INNER JOIN `' . _DB_PREFIX_ . 'order_state_lang` osl
            ON (os.`id_order_state` = osl.`id_order_state` AND osl.`name` = \'' .
             pSQL($nome_status) . '\')' . $isDeleted;
        
        $id_order_state = (Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql));
        
        return $id_order_state[0]['id_order_state'];
    }

    private function checkIfOrderStatusExists($id_lang, $status_name, $list_states)
    {
        
        if (Tools::isEmpty($list_states) or empty($list_states) or ! isset($list_states)) {
            return true;
        }
        
        $save = true;
        foreach ($list_states as $state) {
            
            if ($state['id_lang'] == $id_lang && $state['name'] == $status_name) {
                $save = false;
                break;
            }
        }

        return $save;
    }

    public function getNotificationUrl()
    {
        return $this->modulo->getNotificationUrl();
    }

    public function getDefaultRedirectionUrl()
    {
        return $this->modulo->getDefaultRedirectionUrl();
    }

    public function getJsBehavior()
    {
        return $this->modulo->getJsBehaviors();
    }

    public function getCssDisplay()
    {
        return $this->modulo->getCssDisplay();
    }

    /**
     * Verify if PagSeguro log file exists.
     * Case log file not exists, try create
     * else create PagSeguro.log into PagseguroLibrary folder into module
     */
    private function verifyLogFile($file)
    {
        try {
            $f = @fopen(_PS_ROOT_DIR_ . $file, 'a');
            fclose($f);
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
}
